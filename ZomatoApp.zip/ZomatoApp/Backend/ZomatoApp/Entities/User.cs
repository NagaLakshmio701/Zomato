﻿using System.ComponentModel.DataAnnotations.Schema; // Provides attributes for configuring the database schema
using System.ComponentModel.DataAnnotations; // Provides validation attributes
using Microsoft.EntityFrameworkCore; // Provides Entity Framework Core functionalities

namespace ZomatoApp_API.Entities
{
    public class User
    {
        [Key] // Specifies that UserID is a primary key
        [Column(TypeName = "varchar")] // Specifies the database column type as varchar
        [StringLength(50)] // Sets the maximum length for the UserID to 50 characters
        public string UserID { get; set; } // Represents the unique identifier for a user

        [Column(TypeName = "varchar")] // Specifies the database column type as varchar
        [StringLength(50)] // Sets the maximum length for the Name to 50 characters
        public string Name { get; set; } // Represents the name of the user

        [Column(TypeName = "varchar")] // Specifies the database column type as varchar
        [StringLength(50)] // Sets the maximum length for the Email to 50 characters
        [EmailAddress] // Validates that the Email property contains a valid email address format
        public string Email { get; set; } // Represents the email address of the user

        [Column(TypeName = "varchar")] // Specifies the database column type as varchar
        [StringLength(50)] // Sets the maximum length for the Password to 50 characters
        public string Password { get; set; } // Represents the password of the user

        [Column(TypeName = "varchar")] // Specifies the database column type as varchar
        [StringLength(50)] // Sets the maximum length for the Role to 50 characters
        public string Role { get; set; } // Represents the role of the user (e.g., Admin, Customer)

        [Column(TypeName = "varchar")] // Specifies the database column type as varchar
        [StringLength(50)] // Sets the maximum length for the Address to 50 characters
        public string Address { get; set; } // Represents the address of the user
    }
}
