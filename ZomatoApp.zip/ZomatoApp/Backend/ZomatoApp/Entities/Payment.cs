﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;


namespace ZomatoApp_API.Entities
{
    public class Payment
    {

        [Key]
        [StringLength(50)]
        [Column(TypeName = "varchar")]
        public string PaymentID { get; set; } // Primary Key as String

        [ForeignKey("Order")]
        [Required]
        [StringLength(50)]
        [Column(TypeName = "varchar")]
        public string OrderID { get; set; } // Foreign Key to Orders table
        [JsonIgnore] public Order? Order { get; set; }

        [ForeignKey("User")]
        [Required]
        [Column(TypeName = "varchar(50)")]

        public String UserID { get; set; } // Foreign Key to Users table
        [JsonIgnore] public User? User { get; set; }


        [Required]
        [StringLength(500)]
        [Column(TypeName = "varchar")]
        public string PaymentMethod { get; set; } // Credit Card, Debit Card, PayPal, etc.


        [Required]

        public int TotalAmount { get; set; }



        [Required]
        [Column(TypeName = "DateTime")]

        public DateTime PaymentDate { get; set; } // Date of the payment

     
    }
}
