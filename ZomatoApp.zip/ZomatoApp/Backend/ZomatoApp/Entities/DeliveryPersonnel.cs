﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using ZomatoApp_API.Entities;
/*using ZomatoApp_API.Migrations;
*/
namespace ZomatoApp_API.Entities
{
    public class DeliveryPersonnel
    {
        [Key]
        [Required]
        [Column(TypeName = "varchar(50)")]
        public string DeliveryPersonnelID { get; set; } // Primary Key as String


        [Column(TypeName = "varchar")] // Specifies the database column type as varchar
        [StringLength(50)] // Sets the maximum length for the Email to 50 characters
        [EmailAddress] // Validates that the Email property contains a valid email address format
        public string Email { get; set; } // Represents the email address of the user

        [Column(TypeName = "varchar")] // Specifies the database column type as varchar
        [StringLength(50)] // Sets the maximum length for the Password to 50 characters
        public string Password { get; set; } // Represents the password of the user


        public int PhoneNumber {  get; set; }



        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
     
    }
}
