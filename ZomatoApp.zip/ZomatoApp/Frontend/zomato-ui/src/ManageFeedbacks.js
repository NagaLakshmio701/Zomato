import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const FeedbackManagement = () => {
  const [feedbacks, setFeedbacks] = useState([]);
  const [filterRating, setFilterRating] = useState({ minRating: 0, maxRating: 5 });
  const [restaurantName, setRestaurantName] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetchFeedbacks();
  }, []);

  const fetchFeedbacks = () => {
    axios
      .get("http://localhost:5141/api/FeedBack/GetAll", {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => setFeedbacks(response.data))
      .catch((error) => console.log(error));
  };

  const handleRatingFilter = () => {
    axios
      .get(`http://localhost:5141/api/FeedBack/GetFeedBackByRating`, {
        params: {
          minRating: filterRating.minRating,
          maxRating: filterRating.maxRating,
        },
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => setFeedbacks(response.data))
      .catch((error) => console.log(error));
  };

  const handleRestaurantFilter = () => {
    axios
      .get(`http://localhost:5141/api/FeedBack/GetRestaurantFeedBack/${restaurantName}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => setFeedbacks(response.data))
      .catch((error) => console.log(error));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "minRating" || name === "maxRating") {
      setFilterRating((prev) => ({
        ...prev,
        [name]: value,
      }));
    } else {
      setRestaurantName(value);
    }
  };

  return (
    <div className="container">
      <h2 className="my-4 text-center">Feedback Management</h2>

      {/* Filters */}
      <div className="mb-5">
        <div className="row">
          <div className="col-md-6">
            <h4 className="mb-3">Filter by Rating</h4>
            <input
              type="number"
              name="minRating"
              value={filterRating.minRating}
              onChange={handleChange}
              placeholder="Min Rating"
              step="0.1"
              className="form-control mb-2"
            />
            <input
              type="number"
              name="maxRating"
              value={filterRating.maxRating}
              onChange={handleChange}
              placeholder="Max Rating"
              step="0.1"
              className="form-control mb-2"
            />
            <button onClick={handleRatingFilter} className="btn btn-primary">
              Apply Rating Filter
            </button>
          </div>

          <div className="col-md-6">
            <h4 className="mb-3">Filter by Restaurant</h4>
            <input
              type="text"
              name="restaurantName"
              value={restaurantName}
              onChange={handleChange}
              placeholder="Restaurant Name"
              className="form-control mb-2"
            />
            <button onClick={handleRestaurantFilter} className="btn btn-primary">
              Apply Restaurant Filter
            </button>
          </div>
        </div>
      </div>

      {/* Feedback Table */}
      <div className="table-responsive">
        <table className="table table-striped table-bordered">
          <thead className="thead-dark">
            <tr>
              <th>Feedback ID</th>
              <th>User ID</th>
              <th>Restaurant ID</th>
              <th>Comments</th>
              <th>Rating</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {feedbacks.length > 0 ? (
              feedbacks.map((feedback) => (
                <tr key={feedback.feedbackID}>
                  <td>{feedback.feedbackID}</td>
                  <td>{feedback.userID}</td>
                  <td>{feedback.restaurantID}</td>
                  <td>{feedback.comments}</td>
                  <td>{feedback.rating}</td>
                  <td>{new Date(feedback.feedbackDate).toLocaleDateString()}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" className="text-center">No feedbacks found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default FeedbackManagement;
