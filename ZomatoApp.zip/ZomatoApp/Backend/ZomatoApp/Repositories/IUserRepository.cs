﻿using System.Collections.Generic;
using System.Threading.Tasks;

using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public interface IUserRepository
    {
        Task Register(User user);
        Task<User> ValidateUser(string email, string password);
        Task<List<User>> GetAllUsers();

        Task<User> GetById(string id);

        Task Delete(string userId);
        Task Update(User user);
    }
}
