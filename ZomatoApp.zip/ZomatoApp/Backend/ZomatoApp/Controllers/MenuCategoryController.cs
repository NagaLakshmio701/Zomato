﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Repositories;

[ApiController]
[Route("api/[controller]")]
public class MenuCategoryController : ControllerBase
{
    private readonly IMenuCategoryRepository _menuCategoryRepository;

    public MenuCategoryController(IMenuCategoryRepository menuCategoryRepository)
    {
        _menuCategoryRepository = menuCategoryRepository;
    }

    // GET: api/MenuCategory
    [HttpGet("GetAll")]
    public async Task<IActionResult> GetAll()
    {
        var menuCategories = await _menuCategoryRepository.GetAll();
        return Ok(menuCategories);
    }

    // GET: api/MenuCategory/{categoryName}
    [HttpGet("GetByCategoryByName/{categoryName}")]
    public async Task<IActionResult> GetByCategoryByName(string categoryName)
    {
        var menuCategory = await _menuCategoryRepository.GetByCategoryByName(categoryName);
        if (menuCategory == null)
        {
            return NotFound();
        }
        return Ok(menuCategory);
    }

    // POST: api/MenuCategory
    [HttpPost("AddCategory")]
    public async Task<IActionResult> Add(MenuCategory menuCategory)
    {
        // Generate a random CategoryID.
        menuCategory.CategoryID = "C" + new Random().Next(1000, 9999);

        await _menuCategoryRepository.Add(menuCategory);
        return Ok(menuCategory);
    }

    // PUT: api/MenuCategory/{id}
    [HttpPut("Update/{id}")]
    public async Task<IActionResult> Update(string id, [FromBody] MenuCategory menuCategory)
    {
        if (id != menuCategory.CategoryID)
        {
            return BadRequest();
        }

        await _menuCategoryRepository.Update(menuCategory);
        return Ok(menuCategory);
    }

    // DELETE: api/MenuCategory/{id}
    [HttpDelete("Delete/{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        await _menuCategoryRepository.Delete(id);
        return Ok();
    }
}
