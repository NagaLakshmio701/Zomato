﻿using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public interface IBucketListRepository
    {



        Task Add(BucketList bucketList);

        Task<BucketList> GetById(string id);

        Task<IEnumerable<BucketList>> GetBucketListByUserID(string userId);

        Task<List<BucketList>> GetAll();
        Task Update(BucketList bucketList);
        Task DeleteById(string id);

        Task DeleteBucketListByUserId(string userId);


    }


}
