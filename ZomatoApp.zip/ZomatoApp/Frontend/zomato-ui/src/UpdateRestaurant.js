import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const UpdateRestaurant = () => {
  const [restaurant, setRestaurant] = useState({});
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const restaurantId = sessionStorage.getItem("RestID");

  useEffect(() => {
    axios
      .get(`http://localhost:5141/api/Restaurant/GetById/${restaurantId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        setRestaurant(response.data);
        setLoading(false);
      })
      .catch((error) => console.log(error));
  }, [restaurantId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setRestaurant((prev) => ({
      ...prev,
      [name]: value,
    }));
    console.log("res",restaurant)
  };

  const handleUpdate = () => {
    console.log("res1", restaurant);
  
    // Convert openingTime and closingTime to HH:MM:SS format
    const formatTime = (time) => {
      const [hours, minutes] = time.split(":");
      return `${hours}:${minutes}:00`;  // Adding seconds as "00"
    };
  
    const updatedRestaurant = {
      ...restaurant,
      openingTime: formatTime(restaurant.openingTime),
      closingTime: formatTime(restaurant.closingTime),
    };
  
    axios
      .put("http://localhost:5141/api/Restaurant/UpdateRestaurant", updatedRestaurant, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        console.log("afterUpdate", response.data);
        alert("Restaurant updated successfully!");
        navigate("/manage-restaurants");
      })
      .catch((error) => console.log(error));
  };
  
  if (loading) return <p>Loading...</p>;

  return (
    <div className="container">
      <h2>Update Restaurant</h2>
      <form>
        <div className="mb-3">
          <label>Restaurant Name</label>
          <input
            type="text"
            name="restaurantName"
            value={restaurant.restaurantName || ''}
            onChange={handleChange}
          />
        </div>
        <div className="mb-3">
          <label>Location</label>
          <input
            type="text"
            name="location"
            value={restaurant.location || ''}
            onChange={handleChange}
          />
        </div>

        <div className="mb-3">
          <label>Phone Number</label>
          <input
            type="text"
            name="phoneNumber"
            value={restaurant.phoneNumber || ''}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label>Opening Time</label>
          <input
            type="time"
            name="openingTime"
            value={restaurant.openingTime || ''}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label>Closing Time</label>
          <input
            type="time"
            name="closingTime"
            value={restaurant.closingTime || ''}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        {/* Add fields for other properties here */}
        <button type="button" onClick={handleUpdate}>Save</button>
      </form>
    </div>
  );
};

export default UpdateRestaurant;
