﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Repositories;

namespace ZomatoApp_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {

            private readonly IPaymentRepository _paymentRepository;

            public PaymentController(IPaymentRepository paymentRepository)
            {
                _paymentRepository = paymentRepository;
            }

            [HttpGet, Route("GetAll")]
            public async Task<IActionResult> GetAll()
            {
                try
                {
                    return Ok(await _paymentRepository.GetAll());
                }
                catch (Exception ex)
                {

                    return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
                }
        }

            [HttpGet, Route("GetById/{Uid}")]
            public async Task<IActionResult> GetById([FromRoute] string Uid)
            {
                try
                {
                    var payment = await _paymentRepository.GetById(Uid);
                    if (payment == null)
                    {
                        return NotFound();
                    }
                    return Ok(payment);
                }
                catch (Exception ex)
                {

                    return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
                }
            }

        /*        [Authorize(Roles = "Admin")] */

            [HttpPost, Route("AddPayment")]

       public async Task<IActionResult> Add([FromBody] Payment payment)
            {
                try
                {
                    payment.PaymentID = "p" + new Random().Next(1000, 9999);

                    await _paymentRepository.Add(payment);
                    return Ok(payment);
                }
                catch (Exception ex)
                {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.InnerException?.Message ?? ex.Message });
            }
        }

            [HttpPut, Route("EditPayment")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit([FromBody] Payment payment)
            {
                try
                {
                    await _paymentRepository.Update(payment);
                    return Ok(payment);
                }
                catch (Exception ex)
                {

                    return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
                }
            }

            [HttpDelete, Route("DeletePayment/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete([FromRoute] string id)
            {

            try
            {
                await _paymentRepository.DeleteById(id);
                return Ok();
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }
        }
    }


