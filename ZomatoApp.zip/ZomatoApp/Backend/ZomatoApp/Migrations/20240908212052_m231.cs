﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ZomatoApp_API.Migrations
{
    /// <inheritdoc />
    public partial class m231 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DeliveryPersonnels_Users_UserID",
                table: "DeliveryPersonnels");

            migrationBuilder.DropIndex(
                name: "IX_DeliveryPersonnels_UserID",
                table: "DeliveryPersonnels");

            migrationBuilder.DropColumn(
                name: "UserID",
                table: "DeliveryPersonnels");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "UserID",
                table: "DeliveryPersonnels",
                type: "varchar(50)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryPersonnels_UserID",
                table: "DeliveryPersonnels",
                column: "UserID");

            migrationBuilder.AddForeignKey(
                name: "FK_DeliveryPersonnels_Users_UserID",
                table: "DeliveryPersonnels",
                column: "UserID",
                principalTable: "Users",
                principalColumn: "UserID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
