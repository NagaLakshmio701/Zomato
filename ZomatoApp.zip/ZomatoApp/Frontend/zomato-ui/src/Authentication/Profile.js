import axios from "axios";
import { useEffect, useState } from "react";
import { Form, Button, Table, Card, Container, Row, Col } from 'react-bootstrap';

const Profile = () => {
    const [user, setUser] = useState(null); // Store user data
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isEditing, setIsEditing] = useState(false); // Track edit mode
    const [updatedUser, setUpdatedUser] = useState({
        name: '',
        email: '',
        address: ''
    }); // Store updated user data
    const [orderHistory, setOrderHistory] = useState(null); // Store order history

    useEffect(() => {
        const userId = sessionStorage.getItem("userid");
        const token = sessionStorage.getItem("token");

        if (userId && token) {
            axios
                .get(`http://localhost:5141/api/Authenticate/GetById/${userId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                })
                .then((response) => {
                    setUser(response.data);
                    setUpdatedUser({
                        name: response.data.name,
                        email: response.data.email,
                        address: response.data.address,
                        password: response.data.password,
                        role: response.data.role,
                        userID: response.data.userID,
                    });
                    setLoading(false);
                })
                .catch((error) => {
                    setError(error);
                    setLoading(false);
                });
        } else {
            setError("User ID or token missing.");
            setLoading(false);
        }
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setUpdatedUser((prevUser) => ({
            ...prevUser,
            [name]: value,
        }));
    };

    const handleUpdate = () => {
        const token = sessionStorage.getItem("token");
        axios.put(`http://localhost:5141/api/Authenticate/EditUser`, updatedUser, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        })
        .then((response) => {
            alert("User updated successfully!");
            setIsEditing(false);
            setUser(response.data); // Update user info after successful update
        })
        .catch((error) => {
            console.error("Error updating user:", error);
            alert("Failed to update user.");
        });
    };

    const handleOrderHistory = () => {
        const UserId = sessionStorage.getItem("userid");
        axios
            .get(`http://localhost:5141/api/OrderItem/GetByUserID/${UserId}`)
            .then((response) => {
                console.log("Order History:", response.data);
                setOrderHistory(response.data); // Store the fetched order history
            })
            .catch((error) => {
                console.error("Error fetching order history:", error);
            });
    };

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error.message}</p>;

    return (
        <Container className="mt-5">
            <Row>
                <Col md={8} className="mx-auto">
                    <Card>
                        <Card.Header as="h3" className="text-center">Profile Information</Card.Header>
                        <Card.Body>
                            <Form>
                                <Table striped bordered hover className="text-center">
                                    <thead className="table-primary">
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Address</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {isEditing ? (
                                            <tr>
                                                <td>
                                                    <Form.Control
                                                        type="text"
                                                        name="name"
                                                        value={updatedUser.name}
                                                        onChange={handleInputChange}
                                                    />
                                                </td>
                                                <td>
                                                    <Form.Control
                                                        type="text"
                                                        name="email"
                                                        value={updatedUser.email}
                                                        onChange={handleInputChange}
                                                    />
                                                </td>
                                                <td>
                                                    <Form.Control
                                                        type="text"
                                                        name="address"
                                                        value={updatedUser.address}
                                                        onChange={handleInputChange}
                                                    />
                                                </td>
                                            </tr>
                                        ) : (
                                            <tr>
                                                <td>{user.name}</td>
                                                <td>{user.email}</td>
                                                <td>{user.address}</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </Table>

                                <div className="text-center">
                                    {isEditing ? (
                                        <Button variant="success" onClick={handleUpdate} className="me-2">Save</Button>
                                    ) : (
                                        <Button variant="primary" onClick={() => setIsEditing(true)} className="me-2">Edit</Button>
                                    )}
                                    {user.role === "User" && (
                                        <Button variant="info" onClick={handleOrderHistory}>
                                            View Order History
                                        </Button>
                                    )}
                                </div>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            {orderHistory && user.role === "User" && (
                <Row className="mt-5">
                    <Col md={8} className="mx-auto">
                        <Card>
                            <Card.Header as="h4">Order History</Card.Header>
                            <Card.Body>
                                <ul className="list-group">
                                    {orderHistory.map((item, index) => (
                                        <li className="list-group-item" key={`${item.orderItemID}-${index}`}>
                                            {item.itemName} - {item.quantity} - ${item.price} - {item.date} - {item.restaurantName} - Total: ${item.totalPrice}
                                        </li>
                                    ))}
                                </ul>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            )}
        </Container>
    );
};

export default Profile;
