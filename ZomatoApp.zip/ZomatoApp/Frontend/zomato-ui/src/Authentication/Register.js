import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const Register = () => {
  const [user, setUser] = useState({
    userID: '',
    name: '',
    email: '',
    password: '',
    role: 'User', // Default to "User"
    address: '',
    restaurantName: '' // New field for Restaurant Name
  });
  const [err, setErr] = useState('');
  const [message, setMessage] = useState('');

  const navigate = useNavigate(); // Initialize navigate

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({
      ...user,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    console.log(user);
    e.preventDefault();

    // Clear previous messages
    setErr('');
    setMessage('');

    axios.post('http://localhost:5141/api/Authenticate/Register', user)
      .then((response) => {
        if (response.status === 204) {
          setMessage("Registration failed. Please try again.");
        } else {
          setMessage('You are registered successfully!');
          setTimeout(() => {
            navigate('/login'); // Adjust the path according to your route configuration
          }, 1500); // 2 seconds delay
        }
      })
      .catch((error) => {
        setErr('An error occurred. Please try again.');
      });
  };

  return (
    <div 
      className="container-fluid vh-100 d-flex justify-content-center align-items-center bg-light"
      style={{ 
        backgroundImage: 'url("https://th.bing.com/th/id/OIP.673SuHWvSzJubIRWYqLsZAAAAA?rs=1&pid=ImgDetMain")',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="card shadow-lg" style={{ height: '70%', width: '250%', maxWidth: '700px' }}>
        <div className="card-body p-4">
          <h3 className="card-title text-center mb-4">
            <i className="bi bi-person-circle"></i> Register
          </h3>
          <form onSubmit={handleSubmit}>
            <div className="form-floating mb-3">
              <input
                type="text"
                name="name"
                value={user.name}
                onChange={handleChange}
                className="form-control"
                id="floatingName"
                placeholder="John Doe"
                required
              />
              <label htmlFor="floatingName">Name</label>
            </div>
            <div className="form-floating mb-3">
              <input
                type="email"
                name="email"
                value={user.email}
                onChange={handleChange}
                className="form-control"
                id="floatingEmail"
                placeholder="name@example.com"
                required
              />
              <label htmlFor="floatingEmail">Email</label>
            </div>
            <div className="form-floating mb-3">
              <input
                type="password"
                name="password"
                value={user.password}
                onChange={handleChange}
                className="form-control"
                id="floatingPassword"
                placeholder="Password"
                required
              />
              <label htmlFor="floatingPassword">Password</label>
            </div>
            <div className="form-floating mb-3">
              <select
                name="role"
                value={user.role}
                onChange={handleChange}
                className="form-select"
                id="floatingRole"
                required
              >
                <option value="User">User</option>
                <option value="Restaurant Owner">Restaurant Owner</option>
              </select>
              <label htmlFor="floatingRole">Role</label>
            </div>

            {user.role === 'Restaurant Owner' && (
              <div className="form-floating mb-3">
                <input
                  type="text"
                  name="restaurantName"
                  value={user.restaurantName}
                  onChange={handleChange}
                  className="form-control"
                  id="floatingRestaurantName"
                  placeholder="Restaurant Name"
                  required
                />
                <label htmlFor="floatingRestaurantName">Restaurant Name</label>
              </div>
            )}

            <div className="form-floating mb-3">
              <input
                type="text"
                name="address"
                value={user.address}
                onChange={handleChange}
                className="form-control"
                id="floatingAddress"
                placeholder="1234 Main St"
                required
              />
              <label htmlFor="floatingAddress">Address</label>
            </div>
            <div className="d-grid">
              <button type="submit" className="btn btn-primary btn-lg">Register</button>
            </div>
            {message && <div className="alert alert-success mt-2">{message}</div>}
            {err && <div className="alert alert-danger mt-3">{err}</div>}
          </form>
        </div>
      </div>
    </div>
  );
};

export default Register;
