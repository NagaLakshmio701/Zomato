import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import Header  from "../Layout/Header";

import Footer  from "../Layout/Footer";
// Define category-to-image mapping

const categoryImages = {
  Biryani: 'https://assets.architecturaldigest.in/photos/600849631dd783c692024e30/master/w_1600%2Cc_limit/Mumbai-Best-Biryani-Awadhi-gosht-chap-biryani-at-Ummrao.jpg',
  Pizza: 'https://1.bp.blogspot.com/-CNzUMIzUQQM/V9p6d7-4PqI/AAAAAAABb2g/o2-Fir11lp0OBLdFd5YXMFetf9Jmc4o5QCLcB/s1600/Gluten%2BFree%2BMargherita%2BPizza%2B%25281%2529.jpg',
  Tiffins: 'https://www.lekhafoods.com/media/1051178/hurulikaalu-dosa.jpg',
  Milkshakes: 'https://th.bing.com/th/id/OIP.WgOYHxlF56xg08iv2TY1-wHaLF?w=186&h=278&c=7&r=0&o=5&dpr=1.3&pid=1.7',
  IceCream: 'https://th.bing.com/th/id/OIP.LtMMcUPnr4Y2elP74r6LtQHaHO?w=155&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7',
  Cake: 'https://th.bing.com/th/id/OIP.hWxwGuT35CNKUoNdgitZ8QHaLH?w=186&h=279&c=7&r=0&o=5&dpr=1.3&pid=1.7',
};

const MenuItems = () => {
  const { foodName } = useParams();
  const [menuItems, setMenuItems] = useState([]);
  const [addedItems, setAddedItems] = useState({});

  useEffect(() => {
    const fetchMenuItems = async () => {
      try {
        const response = await axios.get(`http://localhost:5141/api/MenuItems/category/${encodeURIComponent(foodName)}`,{
            headers: {
              Authorization:` Bearer ${sessionStorage.getItem("token")}`,
            },
          });
        setMenuItems(response.data);
      } catch (error) {
        console.error("Error fetching menu items:", error);
      }
    };

    fetchMenuItems();
  }, [foodName]);

  const addToCart = (mid) => {
 const userID = sessionStorage.getItem("userid");

  if (!userID) {
    // If no user is logged in, show an alert and return early
    alert("Please login before adding to cart.");
    return;
  }
    const getPriceFromSession = (menuItemID) => {
      return localStorage.getItem(`${menuItemID}_price`);
    };
    const price = getPriceFromSession(mid);
    const cart = {
      bucketListID: "0", // Ensure this is correct or let the server generate it
      userID: sessionStorage.getItem("userid"),
      menuItemID: mid,
      date: new Date(), // Example for current date
      price: price, // Convert to number if needed
      quantity: 1, // Default value
      totalPrice: parseFloat(price) * 1 // Example calculation
    };
    console.log(cart);
    axios.post("http://localhost:5141/api/BucketList/AddBucketList", cart, {
      headers: {
        Authorization:` Bearer ${sessionStorage.getItem("token")}`,
      },
    })
    .then((response) => {
      if (response.status === 200) {
        setAddedItems((prevState) => ({
          ...prevState,
          [mid]: true, // Only update the state for the clicked menuItemID
        }));
      }
      console.log(response);
    })
    .catch((error) => console.log(error));
  };

  return (
<>
<Header/>
<Container className="my-5">
      <h1 className="mb-4 text-center">{foodName}</h1>
      <Row>
        {menuItems.map((item) => {
          // Determine image URL based on the item's category
          const itemImage = categoryImages[item.categoryName] || 'https://via.placeholder.com/400x300?text=No+Image+Available'; // Fallback image

          return (
            <Col md={4} key={item.menuItemID} className="mb-4">
              <Card className="h-100">
                <Card.Img variant="top" src={itemImage} alt={item.description} style={{ height: '200px', objectFit: 'cover' }} />
                <Card.Body>
                  <Card.Title>{item.restaurantName}</Card.Title>
                  <Card.Subtitle className="mb-2 text-muted">{item.categoryName} - {item.subCategoryName}</Card.Subtitle>
                  <Card.Text>
                    {item.description}
                  </Card.Text>
                  <Card.Text>
                    <strong>Price: ${item.price}</strong>
                  </Card.Text>
                  <Button
                    key={item.menuItemID}
                    variant="primary"
                    onClick={() => addToCart(item.menuItemID)}
                    disabled={addedItems[item.menuItemID]} // Disable only the clicked item
                  >
                    {addedItems[item.menuItemID] ? "Added" : "Add to Cart"}
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          );
        })}
      </Row>
    </Container>
  <Footer/>
    </>
  );
};

export default MenuItems;