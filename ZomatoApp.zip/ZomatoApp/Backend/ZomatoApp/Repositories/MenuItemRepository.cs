﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ZomatoApp_API.Entities;
using ZomatoApp_API.DTOS;


namespace ZomatoApp_API.Repositories
{
    public class MenuItemRepository : IMenuItemRepository
    {
        private readonly ZomatoAppDBContext _context;

        public MenuItemRepository(ZomatoAppDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<MenuItem>> GetAll()
        {
            return await _context.MenuItems
                                 .Include(mi => mi.Restaurant)
                                 .Include(mi => mi.MenuCategory)
                                 .Include(mi => mi.MenuSubCategory)
                                 .ToListAsync();
        }

        public async Task<IEnumerable<MenuItemDTO>> GetByUId(string Uid)
        {

            var items = await (from m in _context.MenuItems
                               where m.Restaurant.OwnerID == Uid
                               select new MenuItemDTO()
                               {
                                   MenuItemID = m.MenuItemID,
                                   RestaurantID = m.RestaurantID,
                                   RestaurantName = m.Restaurant.RestaurantName,
                                   CategoryName = m.MenuCategory.CategoryName,
                                   SubCategoryName = m.MenuSubCategory.SubCategoryName,
                                   Price = m.Price,
                                   Description = m.Description
                               }).ToListAsync();

            return items;

        }

        public async Task<IEnumerable<MenuItemDTO>> GetMenuByCategoryName(string categoryName)
        {
            var items = await (from m in _context.MenuItems
                               where m.MenuCategory.CategoryName == categoryName
                               select new MenuItemDTO()
                               {
                                   MenuItemID = m.MenuItemID,
                                   RestaurantID = m.RestaurantID,
                                   RestaurantName = m.Restaurant.RestaurantName,
                                   CategoryName = m.MenuCategory.CategoryName,
                                   SubCategoryName = m.MenuSubCategory.SubCategoryName,
                                   Price = m.Price,
                                   Description = m.Description
                               }).ToListAsync();

            return items;
        }

        public async Task<IEnumerable<MenuItem>> GetMenuBySubCategoryName(string subCategoryName)
        {
            return await _context.MenuItems
                                 .Include(mi => mi.MenuSubCategory)
                                 .Where(mi => mi.MenuSubCategory.SubCategoryName == subCategoryName)
                                 .ToListAsync();
        }
        public async Task<List<MenuItemDTO>> GetMenuByRestaurantName(string restaurantName)
        {
            var items = await (from m in _context.MenuItems
                               where m.Restaurant.RestaurantName == restaurantName
                               select new MenuItemDTO()
                               {
                                   MenuItemID = m.MenuItemID,
                                   RestaurantID = m.RestaurantID,
                                   RestaurantName = m.Restaurant.RestaurantName,
                                   CategoryName = m.MenuCategory.CategoryName,
                                   SubCategoryName = m.MenuSubCategory.SubCategoryName,
                                   Price = m.Price,
                                   Description = m.Description
                               }).ToListAsync();

            return items;
        }

     
        public async Task<IEnumerable<MenuItemDTO>> GetItemsByFilterAsync(
     decimal? minPrice,
     decimal? maxPrice,
     string? type,
     decimal? rating,
     string? categoryName,
     string? restaurantname
 )
        {
            var query = (from m in _context.MenuItems
                .Where(i => (!minPrice.HasValue || i.Price >= minPrice.Value) &&
                            (!maxPrice.HasValue || i.Price <= maxPrice.Value) &&
                            (string.IsNullOrEmpty(type) || i.MenuSubCategory.Type == type) &&
                            (!rating.HasValue || i.Restaurant.Rating >= rating.Value) &&
                            (string.IsNullOrEmpty(categoryName) || i.MenuCategory.CategoryName == categoryName) &&
                            (string.IsNullOrEmpty(restaurantname) || i.Restaurant.RestaurantName == restaurantname))
                         select new MenuItemDTO()
                         {

                             MenuItemID = m.MenuItemID,
                             RestaurantID = m.RestaurantID,
                             RestaurantName = m.Restaurant.RestaurantName,
                             CategoryName = m.MenuCategory.CategoryName,
                             SubCategoryName = m.MenuSubCategory.SubCategoryName,
                             Price = m.Price,
                             Description = m.Description


                         }).ToListAsync();





            return await query;
        }



        public async Task Add(MenuItem menuItem)
        {
            await _context.MenuItems.AddAsync(menuItem);
            await _context.SaveChangesAsync();
        }

        public async Task Update(MenuItem menuItem)
        {
            _context.MenuItems.Update(menuItem);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(string id)
        {
            var menuItem = await _context.MenuItems.FindAsync(id);
            if (menuItem != null)
            {
                _context.MenuItems.Remove(menuItem);
                await _context.SaveChangesAsync();
            }
        }
    }
}
