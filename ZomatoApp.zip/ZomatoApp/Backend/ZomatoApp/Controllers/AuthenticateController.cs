﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ZomatoApp_API.Repositories;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Models;

namespace ZomatoApp_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _configuration;

        public AuthenticateController(IUserRepository userRepository, IConfiguration configuration)
        {
            _userRepository = userRepository;
            _configuration = configuration;
        }

        [HttpPost, Route("Register")]
        [AllowAnonymous]




        public async Task<IActionResult> AddUser(User user)
        {
            try
            {
                if (string.IsNullOrEmpty(user.UserID) || user.UserID == "string")
                {
                    user.UserID = "U" + new Random().Next(1000, 9999);
                }

                await Task.Run(() => _userRepository.Register(user));

                return Ok(user);
            }
            catch (Exception ex)
            {
             
                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }


        [HttpPost, Route("Validate")]
        [AllowAnonymous]
        public async Task<IActionResult> ValidateUser(Login login)
        {
            try
            {
                AuthResponse authResponse = null;
                var user = await Task.Run(() => _userRepository.ValidateUser(login.Email, login.Password));
                if (user != null)
                {
                    authResponse = new AuthResponse()
                    {
                        UserID = user.UserID,
                        Name=user.Name,
                        Role = user.Role,
                        Token = GetToken(user),
                    };
                }

                return Ok(authResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }



        // Endpoint to retrieve a specific bucket list by its ID.
        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> GetById([FromRoute] string id)
        {
            try
            {
                // Retrieve the bucket list by ID asynchronously.
                var user = await _userRepository.GetById(id);

                // If the bucket list is not found, return a 404 status code.
                if (user == null)
                {
                    return NotFound();
                }

                // Return the found bucket list.
                return Ok(user);
            }
            catch (Exception ex)
            {
                // Handle any exceptions and return a 500 status code with the error message.
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpGet, Route("GetAllUsers")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
               
                return Ok(await _userRepository.GetAllUsers());

            }
            catch (Exception ex)
            {
            
                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpPut, Route("EditUser")]
        [Authorize(Roles = "User,Admin,Owner")]
        public async Task<IActionResult> Update([FromBody] User user)
        {
            try
            {
                await  _userRepository.Update(user);
                return StatusCode(200, user);
               
            }
            catch (Exception ex)
            {
               
                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpDelete, Route("DeleteUser")]
        [Authorize(Roles = "Admin,User,Owner")]
        public async Task<IActionResult> Delete([FromQuery] string UserId)
        {
            try
            {
                await _userRepository.Delete(UserId);
                return Ok();
            }
            catch (Exception ex)
            {
                
                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        private string GetToken(User user)
        {
            var issuer = _configuration["Jwt:Issuer"];
            var audience = _configuration["Jwt:Audience"];
            var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]);

            var signingCredentials = new SigningCredentials(
                new SymmetricSecurityKey(key),
                SecurityAlgorithms.HmacSha512Signature
            );

            var subject = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, user.Name),
                new Claim(ClaimTypes.Role, user.Role),
            });

            var expires = DateTime.UtcNow.AddMinutes(10);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = subject,
                Expires = expires,
                Issuer = issuer,
                Audience = audience,
                SigningCredentials = signingCredentials
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
