﻿/*using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ZomatoApp_API.Entities
{
    public class Restaurant
    {
        [Key]
        [Column(TypeName ="varchar")]
        [StringLength(50)]
        public string RestaurantID { get; set; }

        [Required]
        [ForeignKey("User")]
        [Column(TypeName = "varchar")]
        [StringLength(50)]

        public string OwnerID { get; set; } // Foreign Key to Users table
        [JsonIgnore] public User? User { get; set; }  // Navigation property


        [Required]
        [StringLength(200)]
        [Column(TypeName = "varchar")]

        public string RestaurantName { get; set; }

        [Required]
        [StringLength(500)]
        [Column(TypeName = "varchar")]

        public string Location { get; set; }

 

        [StringLength(15)]
        public string PhoneNumber { get; set; }

*//*        public TimeSpan OpeningHours { get; set; }
*//*      public TimeSpan OpeningTime { get; set; }
        public TimeSpan ClosingTime { get; set; }


    }

}

*/

using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;

namespace ZomatoApp_API.Entities
{
    public class Restaurant
    {
        [Key]
        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string RestaurantID { get; set; }

        [Required]
        [ForeignKey("User")]
        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string OwnerID { get; set; } // Foreign Key to Users table
        [JsonIgnore] public User? User { get; set; }  // Navigation property

        [Required]
        [StringLength(200)]
        [Column(TypeName = "varchar")]

        public string RestaurantName { get; set; }

        [Required]
        [StringLength(500)]
        [Column(TypeName = "varchar")]
        public string Location { get; set; }

        [StringLength(15)]
        public string PhoneNumber { get; set; }


        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Rating { get; set; }

        public TimeSpan OpeningTime { get; set; }
        public TimeSpan ClosingTime { get; set; }

    }
}
