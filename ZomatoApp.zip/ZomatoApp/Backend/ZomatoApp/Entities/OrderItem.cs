﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ZomatoApp_API.Entities
{
    public class OrderItem
    {


        [Key]
        [Column(TypeName = "varchar(50)")]
        public string OrderItemID { get; set; }


        [ForeignKey("User")]
        [Required]
        [Column(TypeName = "varchar(50)")]

        public String UserID { get; set; }
        [JsonIgnore] public User? User { get; set; }

        [ForeignKey("Order")]
        [Required]
        [Column(TypeName = "varchar(50)")]

        public String OrderID { get; set; }
        [JsonIgnore] public Order? Order { get; set; }

        public DateTime? OrderDate { get; set; }


        [ForeignKey("MenuItem")]
        [Required]
        [Column(TypeName = "varchar(50)")]
        public string MenuItemID { get; set; }
        [JsonIgnore] public MenuItem? MenuItem { get; set; }


        [Required]
        
        public int Quantity {  get; set; }

        [Required]

        public int Price {  get; set; }



    }
}
