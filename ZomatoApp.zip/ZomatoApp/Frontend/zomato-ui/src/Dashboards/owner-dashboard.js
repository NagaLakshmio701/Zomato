import React from 'react';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import { PencilSquare, BoxArrowInDown, StarFill, CreditCard, HouseDoor } from 'react-bootstrap-icons';
import './Dashboard.css'; // Assuming you're adding some custom CSS for hover effects

const RestaurantOwnerDashboard = () => {
  return (
    <Container className="mt-5">
      <h2 className="text-center mb-4">Restaurant Owner Dashboard</h2>
      <Row>
        {/* Manage Menu */}
        <Col md={4}>
          <Card className="mb-4 shadow-sm dashboard-card">
            <Card.Body>
              <div className="d-flex align-items-center mb-3">
                <PencilSquare className="me-2 dashboard-icon" size={30} />
                <Card.Title>Manage Menu</Card.Title>
              </div>
              <Card.Text>Add, edit, or delete menu items for your restaurant.</Card.Text>
              <Button variant="primary" href="/manage-menu" className="w-100 hover-effect">
                Manage Menu
              </Button>
            </Card.Body>
          </Card>
        </Col>

        {/* View Orders */}
        <Col md={4}>
          <Card className="mb-4 shadow-sm dashboard-card">
            <Card.Body>
              <div className="d-flex align-items-center mb-3">
                <BoxArrowInDown className="me-2 dashboard-icon" size={30} />
                <Card.Title>View Orders</Card.Title>
              </div>
              <Card.Text>Track and manage incoming customer orders.</Card.Text>
              <Button variant="primary" href="/view-orders" className="w-100 hover-effect">
                View Orders
              </Button>
            </Card.Body>
          </Card>
        </Col>

        {/* View Customer Feedback */}
        <Col md={4}>
          <Card className="mb-4 shadow-sm dashboard-card">
            <Card.Body>
              <div className="d-flex align-items-center mb-3">
                <StarFill className="me-2 dashboard-icon" size={30} />
                <Card.Title>View Customer Feedback</Card.Title>
              </div>
              <Card.Text>See feedback and ratings from your customers.</Card.Text>
              <Button variant="primary" href="/view-feedback" className="w-100 hover-effect">
                View Feedback
              </Button>
            </Card.Body>
          </Card>
        </Col>

        {/* View Transactions */}
        <Col md={4}>
          <Card className="mb-4 shadow-sm dashboard-card">
            <Card.Body>
              <div className="d-flex align-items-center mb-3">
                <CreditCard className="me-2 dashboard-icon" size={30} />
                <Card.Title>View Transactions</Card.Title>
              </div>
              <Card.Text>Review financial transactions related to your restaurant.</Card.Text>
              <Button variant="primary" href="/view-transactions" className="w-100 hover-effect">
                View Transactions
              </Button>
            </Card.Body>
          </Card>
        </Col>

        {/* Update Restaurant Profile */}
        <Col md={4}>
          <Card className="mb-4 shadow-sm dashboard-card">
            <Card.Body>
              <div className="d-flex align-items-center mb-3">
                <HouseDoor className="me-2 dashboard-icon" size={30} />
                <Card.Title>Update Restaurant Profile</Card.Title>
              </div>
              <Card.Text>Edit your restaurant's details like name, address, and contact info.</Card.Text>
              <Button variant="primary" href="/view-restaurant-profile" className="w-100 hover-effect">
                Update Profile
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default RestaurantOwnerDashboard;
