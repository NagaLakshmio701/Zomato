import axios from "axios";
import { useRef, useState } from "react";
import { Modal, Button, Form, Spinner, Alert } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const Payment = () => {
  const PaymentMode = useRef();
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const PaymentHandler = (e) => {
    e.preventDefault(); // Prevent default form submission

    setLoading(true);
    setError(null);

    const pay = {
      paymentID: "0",
      orderID: localStorage.getItem("oid"),
      paymentMethod: PaymentMode.current.value,
      totalAmount: localStorage.getItem("totalPrice"),
      paymentDate: new Date(),
      userId: sessionStorage.getItem("userid"),
    };

    axios
      .post("http://localhost:5141/api/Payment/AddPayment", pay, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        console.log("Payment response:", response.data);
        // Show modal dialog after successful payment
        setShowModal(true);
      })
      .catch((error) => {
        console.error("Payment error:", error);
        setError("Failed to process payment. Please try again.");
      })
      .finally(() => {
        setLoading(false);
      });
  };


  const handleCloseModal = () => {
    setShowModal(false);
    navigate("/"); // Navigate to UserDashboard after closing the modal
  };
  return (
    <div className="container mt-5">
      <Form onSubmit={PaymentHandler}>
        <Form.Group>
          <Form.Label>Order ID</Form.Label>
          <Form.Control
            type="text"
            value={localStorage.getItem("oid")}
            readOnly
          />
        </Form.Group>
        <Form.Group className="mt-3">
          <Form.Label>Transaction Amount</Form.Label>
          <Form.Control
            type="text"
            value={localStorage.getItem("totalPrice")}
            readOnly
          />
        </Form.Group>
        <Form.Group className="mt-3">
          <Form.Label>Payment Mode</Form.Label>
          <Form.Control as="select" ref={PaymentMode}>
            <option>Debit</option>
            <option>Credit</option>
            <option>UPI</option>
          </Form.Control>
        </Form.Group>
        <Button className="mt-3" variant="primary" type="submit" disabled={loading}>
          {loading ? <Spinner animation="border" size="sm" /> : "Make Transaction"}
        </Button>
      </Form>

      {/* Error Alert */}
      {error && <Alert variant="danger" className="mt-3">{error}</Alert>}

      {/* Modal for confirmation */}
      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Order Confirmation</Modal.Title>
        </Modal.Header>
        <Modal.Body>Your order has been successfully confirmed!</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default Payment;
