﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Numerics;
using System.Text.Json.Serialization;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Entities
{
    public class Order
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string OrderID { get; set; }


        [ForeignKey("User")]
        [Required]
        [Column(TypeName = "varchar(50)")]

        public String UserID { get; set; }
        [JsonIgnore] public User? User { get; set; }


        public int TotalPrice { get; set; }



        [Required]
        [Column(TypeName ="DateTime")]
        public DateTime OrderDate { get; set; }


        [Required]
        [Column(TypeName ="Varchar(50)")]
        public string OrderStatus { get; set; } // Possible values: Placed, In Progress, Delivered, Cancelled


    }
}
