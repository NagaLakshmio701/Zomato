import React from 'react';
import Header  from './Layout/Header';
import Footer from './Layout/Footer';
import { Outlet } from 'react-router-dom';

const Layout = () => {
  return (
    <>
      {/* Header */}
      <Header />

      {/* Main content, the dynamic area for child routes */}
      <div className="content">
        <Outlet />
      </div>

      {/* Footer */}
      <Footer />
    </>
  );
};

export default Layout;
