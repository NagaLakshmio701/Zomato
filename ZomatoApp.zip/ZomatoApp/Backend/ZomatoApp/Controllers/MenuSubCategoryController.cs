﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Repositories;

namespace ZomatoApp_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MenuSubCategoryController : ControllerBase
    {
        private readonly IMenuSubCategoryRepository _menuSubCategoryRepository;

        public MenuSubCategoryController(IMenuSubCategoryRepository menuSubCategoryRepository)
        {
            _menuSubCategoryRepository = menuSubCategoryRepository;
        }

        // GET: api/MenuSubCategory
        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            var subCategories = await _menuSubCategoryRepository.GetAll();
            return Ok(subCategories);
        }

        // GET: api/MenuSubCategory/GetBySubCategoryName/{subCategoryName}
        [HttpGet("GetBySubCategoryName/{subCategoryName}")]
        public async Task<IActionResult> GetBySubCategoryName(string subCategoryName)
        {
            var subCategory = await _menuSubCategoryRepository.GetBySubCategoryName(subCategoryName);
            if (subCategory == null)
            {
                return NotFound();
            }
            return Ok(subCategory);
        }


        [HttpGet("GetByCategoryName/{CategoryName}")]
        public async Task<IActionResult> GetByCategoryName(string CategoryName)
        {
            var subCategory = await _menuSubCategoryRepository.GetByCategoryName(CategoryName);
            if (subCategory == null)
            {
                return NotFound();
            }
            return Ok(subCategory);
        }
        // POST: api/MenuSubCategory/AddSubCategory
        [HttpPost("AddSubCategory")]
        public async Task<IActionResult> Add(MenuSubCategory menuSubCategory)
        {
            // Generate a random SubCategoryID if not provided.
            
                menuSubCategory.SubCategoryID = "SC" + new Random().Next(1000, 9999);
            

            await _menuSubCategoryRepository.Add(menuSubCategory);
            return Ok(menuSubCategory);
        }

        // PUT: api/MenuSubCategory/Edit/{id}
        [HttpPut("Edit/{id}")]
        public async Task<IActionResult> Update(string id, MenuSubCategory menuSubCategory)
        {
            if (id != menuSubCategory.SubCategoryID)
            {
                return BadRequest("SubCategoryID mismatch");
            }

            await _menuSubCategoryRepository.Update(menuSubCategory);
            return Ok(menuSubCategory);
        }

        // DELETE: api/MenuSubCategory/Delete/{id}
        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            await _menuSubCategoryRepository.Delete(id);
            return Ok();
        }
    }
}
