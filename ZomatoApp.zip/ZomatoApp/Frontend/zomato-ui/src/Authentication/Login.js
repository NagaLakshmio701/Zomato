import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Container, Form, Button, Alert } from "react-bootstrap";

const Login = () => {
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [err, setErr] = useState("");
  const [validated, setValidated] = useState(false);

  const navigate = useNavigate();

  const validate = (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    if (form.checkValidity() === false) {
      e.stopPropagation();
    } else {
      let user = { email, password: pwd };
      axios
        .post("http://localhost:5141/api/Authenticate/Validate", user)
        .then((response) => {
          if (response.status === 204) {
            setErr("Invalid User Credentials");
          } else {
            let user = response.data;
            console.log("l",response.data)
            sessionStorage.setItem("userid", user.userID);
            sessionStorage.setItem("token", user.token);
            sessionStorage.setItem("user", JSON.stringify(user)); // Store user data (optional)

            if (user.role === "Admin") {
              navigate("/admin-dashboard");  // Correct path
            } else if (user.role === "User") {
              navigate("/");
            } else if (user.role === "Owner" || user.role === "Restaurant Owner") {
              navigate("/owner-dashboard");
            }
          }
        })
        .catch(() => {
          setErr("An error occurred. Please try again.");
        });
    }
    setValidated(true);
  };

  return (
    <Container 
      fluid
      className="d-flex justify-content-center align-items-center"
      style={{ 
        height: '100vh',
        backgroundImage: 'url("https://th.bing.com/th/id/OIP.673SuHWvSzJubIRWYqLsZAAAAA?rs=1&pid=ImgDetMain")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        margin: 0, 
        padding: 0, 
      }}
    >
      <div 
        style={{
          border: '1px solid #ccc',
          padding: '2rem',
          borderRadius: '0.5rem',
          boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
          backgroundColor: '#fff',
          width: '100%',
          maxWidth: '500px',
          height: '50%',
        }}
      >
        <h2 className="mb-4 text-center">Login</h2>
        <Form noValidate validated={validated} onSubmit={validate}>
          {err && <Alert variant="danger">{err}</Alert>}
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="email"
              placeholder="Enter email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              isInvalid={validated && !email}
            />
            <Form.Control.Feedback type="invalid">
              Please provide a valid email address.
            </Form.Control.Feedback>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              value={pwd}
              onChange={(e) => setPwd(e.target.value)}
              required
              isInvalid={validated && !pwd}
            />
            <Form.Control.Feedback type="invalid">
              Password is required.
            </Form.Control.Feedback>
          </Form.Group>

          <Button variant="primary" type="submit" className="w-100">
            Login
          </Button>
        </Form>
      </div>
    </Container>
  );
};

export default Login;
