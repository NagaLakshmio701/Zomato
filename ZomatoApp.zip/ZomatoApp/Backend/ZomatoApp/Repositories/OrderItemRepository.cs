﻿using Microsoft.EntityFrameworkCore;
using ZomatoApp_API.Entities;
using ZomatoApp_API.DTOS;

namespace ZomatoApp_API.Repositories
{
    public class OrderItemRepository:IOrderItemRepository
    {

        private readonly ZomatoAppDBContext _context;

        public OrderItemRepository(ZomatoAppDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<OrderItem>> GetAllOrderItems()
        {
            return await _context.OrderItems.ToListAsync();
        }

        public async Task<List<OrderItemDTO>> GetOrderItemByUserId(string UserId)
        {
            var items = await (from o in _context.OrderItems
                               join m in _context.MenuItems on o.MenuItemID equals m.MenuItemID
                               join oi in _context.Orders on o.OrderID equals oi.OrderID
                               where o.UserID == UserId
                               select new OrderItemDTO()
                               {
                                   OrderItemID = o.OrderItemID,
                                   Price = o.Price,
                                   Quantity = o.Quantity,
                                   UserID = o.UserID,
                                   ItemName = m.Description,
                                   Date = oi.OrderDate,
                                   RestaurantName = m.Restaurant.RestaurantName,
                                   TotalPrice = o.Price * o.Quantity, // Calculate total price per item
                               }).ToListAsync();

            return items;
        }




        public async Task AddOrderItem(OrderItem orderItem)
        {
            _context.OrderItems.Add(orderItem);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateOrderItem(OrderItem orderItem)
        {
            _context.OrderItems.Update(orderItem);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteOrderItem(int orderItemId)
        {
            var orderItem = await _context.OrderItems.FindAsync(orderItemId);
            if (orderItem != null)
            {
                _context.OrderItems.Remove(orderItem);
                await _context.SaveChangesAsync();
            }
        }
    }
}
