﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Repositories;
using Microsoft.AspNetCore.Authorization;

namespace ZomatoAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;

        public OrdersController(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        [HttpGet, Route("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                return Ok(await _orderRepository.GetAll());
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpGet, Route("GetById/{userId}")]
        public async Task<IActionResult> GetById([FromRoute] string userId)
        {
            try
            {
                return Ok(await _orderRepository.GetById(userId));
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }




        [HttpGet("GetBy Date-Range")]
        public async Task<IActionResult> GetOrdersByDateRange([FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
        {
            if (startDate > endDate)
            {
                return BadRequest("Start date cannot be after end date.");
            }

            var orders = await _orderRepository.GetOrdersByDateRange(startDate, endDate);

            if (orders == null || !orders.Any())
            {
                return NotFound("No orders found for the specified date range.");
            }

            return Ok(orders);
        }



        [HttpPut("{orderId}/UpdateOrderstatus")]
        [Authorize(Roles = "Admin,Owner")]

        public async Task<IActionResult> UpdateOrderStatus(string orderId, [FromBody] string newStatus)
        {
            if (string.IsNullOrWhiteSpace(newStatus))
            {
                return BadRequest("Status cannot be empty.");
            }

            var result = await _orderRepository.UpdateOrderStatus(orderId, newStatus);

            if (!result)
            {
                return NotFound("Order not found.");
            }

            return NoContent(); // Status code 204, no content to return
        }
    
    [HttpPost, Route("AddOrder")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Add(Order order)
        {
            try
            {
                order.OrderID = "O" + new Random().Next(1000, 9999);

                await _orderRepository.Add(order);
                return Ok(order);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpPut, Route("EditOrder")]
        [Authorize(Roles = "User")]

        public async Task<IActionResult> Edit([FromBody] Order order)
        {

            try
            {
                await _orderRepository.Update(order);
                return Ok(order);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpDelete, Route("DeleteOrder/{id}")]
        [Authorize(Roles = "User")]

        public async Task<IActionResult> Delete([FromRoute] string id)
        {
            try
            {
                await _orderRepository.DeleteById(id);
                return Ok();
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }
    }
}
