﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ZomatoApp_API.Migrations
{
    /// <inheritdoc />
    public partial class m23 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DeliveryPersonnels_Orders_CurrentOrderID",
                table: "DeliveryPersonnels");

            migrationBuilder.DropIndex(
                name: "IX_DeliveryPersonnels_CurrentOrderID",
                table: "DeliveryPersonnels");

            migrationBuilder.DropColumn(
                name: "CurrentOrderID",
                table: "DeliveryPersonnels");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CurrentOrderID",
                table: "DeliveryPersonnels",
                type: "varchar(50)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryPersonnels_CurrentOrderID",
                table: "DeliveryPersonnels",
                column: "CurrentOrderID");

            migrationBuilder.AddForeignKey(
                name: "FK_DeliveryPersonnels_Orders_CurrentOrderID",
                table: "DeliveryPersonnels",
                column: "CurrentOrderID",
                principalTable: "Orders",
                principalColumn: "OrderID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
