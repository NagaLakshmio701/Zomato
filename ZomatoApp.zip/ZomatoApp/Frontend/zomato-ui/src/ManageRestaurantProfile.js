import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

const ManageRestaurantProfile = () => {
  const [restaurants, setRestaurants] = useState([]);
  const [restaurant, setRestaurant] = useState({
    restaurantID: "0",
    ownerID: sessionStorage.getItem("userid"),
    restaurantName: "",
    location: "",
    phoneNumber: "",
    rating: "",
    openingTime: "",
    closingTime: "",
  });
  const [restaurantDetails, setRestaurantDetails] = useState([]);
  const [restaurantName, setRestaurantName] = useState("");
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [selectedRestaurantId, setSelectedRestaurantId] = useState(null);
  const navigate = useNavigate();
  const ownerId = sessionStorage.getItem("userid");

  useEffect(() => {
    axios
      .get(`http://localhost:5141/api/Restaurant/GetRestaurantByOwnerId/${ownerId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        setRestaurants(response.data);
        setLoading(false);
      })
      .catch((error) => console.log(error));
  }, [ownerId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setRestaurant((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleAddRestaurant = () => {
    const restaurantToSubmit = {
      ...restaurant,
      openingTime: `${restaurant.openingTime}:00`,
      closingTime: `${restaurant.closingTime}:00`,
    };
    axios
      .post("http://localhost:5141/api/Restaurant/AddRestaurant", restaurantToSubmit, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        alert("Restaurant added successfully!");
        window.location.reload();
      })
      .catch((error) => console.log(error));
  };

  const handleEdit = (restaurantId) => {
    const restaurantToEdit = restaurants.find((r) => r.restaurantID === restaurantId);
    setRestaurant(restaurantToEdit);
    setSelectedRestaurantId(restaurantId);
    setEditing(true);
  };

  const handleUpdateRestaurant = () => {
    const restaurantToSubmit = {
      ...restaurant,
      openingTime: `${restaurant.openingTime}`,
      closingTime: `${restaurant.closingTime}`,
    };
    axios
      .put(`http://localhost:5141/api/Restaurant/UpdateRestaurant`, restaurantToSubmit, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        alert("Restaurant updated successfully!");
        setEditing(false);
        window.location.reload();
      })
      .catch((error) => console.log(error));
  };

  const handleDeleteRestaurant = (restaurantId) => {
    axios
      .delete(`http://localhost:5141/api/Restaurant/DeleteRestaurant/${restaurantId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        alert("Restaurant deleted successfully!");
        setRestaurants(restaurants.filter((r) => r.restaurantID !== restaurantId));
      })
      .catch((error) => console.log(error));
  };

  const handleGetRestaurantByName = () => {
    axios
      .get(`http://localhost:5141/api/Restaurant/GetMenuByRestaurantName/${restaurantName}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        setRestaurantDetails(response.data);
      })
      .catch((error) => console.log(error));
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Manage Restaurants</h2>

      <div className="mb-4">
        <h3>Get Restaurant Details by Name</h3>
        <div className="input-group">
          <input
            type="text"
            className="form-control"
            value={restaurantName}
            onChange={(e) => setRestaurantName(e.target.value)}
            placeholder="Enter restaurant name"
          />
          <button onClick={handleGetRestaurantByName} className="btn btn-primary">
            Get Details
          </button>
        </div>
        {restaurantDetails.length > 0 && restaurantDetails.map((r) => (
          <div key={r.restaurantID} className="mt-3">
            <h4>Details for {r.restaurantName}</h4>
            <ul className="list-unstyled">
              <li><strong>RestaurantID:</strong> {r.restaurantID}</li>
              <li><strong>Location:</strong> {r.location}</li>
              <li><strong>Phone Number:</strong> {r.phoneNumber}</li>
              <li><strong>Rating:</strong> {r.rating}</li>
              <li><strong>Opening Time:</strong> {r.openingTime}</li>
              <li><strong>Closing Time:</strong> {r.closingTime}</li>
            </ul>
          </div>
        ))}
      </div>

      <div>
        <h3 className="mb-4">{editing ? "Update Restaurant" : "Add Restaurant"}</h3>
        <form>
          <div className="mb-3">
            <label className="form-label">Restaurant Name</label>
            <input
              type="text"
              name="restaurantName"
              value={restaurant.restaurantName}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Location</label>
            <input
              type="text"
              name="location"
              value={restaurant.location}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Phone Number</label>
            <input
              type="text"
              name="phoneNumber"
              value={restaurant.phoneNumber}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Rating</label>
            <input
              type="number"
              step="0.1"
              name="rating"
              value={restaurant.rating}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Opening Time</label>
            <input
              type="time"
              name="openingTime"
              value={restaurant.openingTime}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Closing Time</label>
            <input
              type="time"
              name="closingTime"
              value={restaurant.closingTime}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          <button
            type="button"
            onClick={editing ? handleUpdateRestaurant : handleAddRestaurant}
            className="btn btn-primary"
          >
            {editing ? "Update" : "Add"} Restaurant
          </button>
        </form>
      </div>

      <div className="mt-4">
        <h3>Restaurant List</h3>
        <table className="table table-bordered table-hover">
          <thead className="table-primary">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Location</th>
              <th>Phone Number</th>
              <th>Rating</th>
              <th>Opening Time</th>
              <th>Closing Time</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {restaurants.map((restaurant) => (
              <tr key={restaurant.restaurantID}>
                <td>{restaurant.restaurantID}</td>
                <td>{restaurant.restaurantName}</td>
                <td>{restaurant.location}</td>
                <td>{restaurant.phoneNumber}</td>
                <td>{restaurant.rating}</td>
                <td>{restaurant.openingTime}</td>
                <td>{restaurant.closingTime}</td>
                <td>
                  <button
                    onClick={() => handleEdit(restaurant.restaurantID)}
                    className="btn btn-warning btn-sm me-2"
                  >
                    Update
                  </button>
                  <button
                    onClick={() => handleDeleteRestaurant(restaurant.restaurantID)}
                    className="btn btn-danger btn-sm"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ManageRestaurantProfile;
