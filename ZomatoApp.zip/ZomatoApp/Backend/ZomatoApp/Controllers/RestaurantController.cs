﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Repositories;

namespace ZomatoApp_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RestaurantController : ControllerBase
    {
        private readonly IRestaurantRepository _repository;
        private readonly ZomatoAppDBContext _context;

        public RestaurantController(IRestaurantRepository repository, ZomatoAppDBContext context)
        {
            _repository = repository;
            _context = context;
        }

        [HttpGet]
        [Route("GetAllRestaurants")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var restaurants = await _repository.GetAll();
                return Ok(restaurants);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }


        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> GetById([FromRoute] string id)
        {
            try
            {
                var restaurant = await _repository.GetById(id);
                if (restaurant == null)
                {
                    return NotFound();
                }
                return Ok(restaurant);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpGet]
        [Route("GetRestaurantByOwnerId/{Ownerid}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetByOwnerId(string Ownerid)
        {
            try
            {
                var restaurant = await _repository.GetByOwnerId(Ownerid);
                if (restaurant == null)
                {
                    return NotFound();
                }
                return Ok(restaurant);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpGet("GetMenuByRestaurantName/{restaurantname}")]
        public async Task<IActionResult> GetByRestaurantName(string restaurantname)
        {
            try
            {
                var restaurant = await _repository.GetMenuByRestaurantName(restaurantname);
                return Ok(restaurant);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }

        }
        [HttpPost]
        [Route("AddRestaurant")]
        [Authorize(Roles = "Owner")]
        public async Task<IActionResult> CreateRestaurant(Restaurant restaurant)
        {
            try
            {
                restaurant.RestaurantID = "R" + new Random().Next(1000, 9999).ToString();
                await _repository.Add(restaurant);
                await _context.SaveChangesAsync();

                return Ok(restaurant);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpPut]
        [Route("UpdateRestaurant")]
        [Authorize(Roles = "Owner,Admin")]
        public async Task<IActionResult> Update( Restaurant restaurant)
        {
            try
            {
                await _repository.Update(restaurant);
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpDelete]
        [Route("DeleteRestaurant/{id}")]
        [Authorize(Roles = "Owner,Admin")]

        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                var restaurant = await _repository.GetByOwnerId(id); // Optionally check if the restaurant exists
                if (restaurant == null)
                {
                    return NotFound(new { message = "Restaurant not found." });
                }

                await _repository.Delete(id);
                return Ok(new { message = "Restaurant deleted successfully." });
            }
            catch (Exception ex)
            {
                // Log the exception details here
                return BadRequest(new { message = "An error occurred while deleting the restaurant.", error = ex.Message });
            }
        }

    }
}
