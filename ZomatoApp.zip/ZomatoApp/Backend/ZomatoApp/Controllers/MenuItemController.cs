﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ZomatoApp_API.DTOS;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Repositories;

[ApiController]
[Route("api/[controller]")]
public class MenuItemsController : ControllerBase
{
    private readonly IMenuItemRepository _menuItemRepository;

    public MenuItemsController(IMenuItemRepository menuItemRepository)
    {
        _menuItemRepository = menuItemRepository;
    }

    // GET: api/MenuItems
    [HttpGet("GetAll")]
    public async Task<IActionResult> GetAll()
    {
        var menuItems = await _menuItemRepository.GetAll();
        return Ok(menuItems);
    }

    // GET: api/MenuItems/{id}
    [HttpGet("GetById/{Uid}")]
    public async Task<IActionResult> GetByUId(string Uid)
    {
        var menuItem = await _menuItemRepository.GetByUId(Uid);
        if (menuItem == null)
        {
            return NotFound();
        }
        return Ok(menuItem);
    }

    // GET: api/MenuItems/category/{categoryName}
    [HttpGet("category/{categoryName}")]
    public async Task<IActionResult> GetMenuByCategoryName(string categoryName)
    {
        var menuItems = await _menuItemRepository.GetMenuByCategoryName(categoryName);
        if (!menuItems.Any())
        {
            return NotFound();
        }
        return Ok(menuItems);
    }

    // GET: api/MenuItems/subcategory/{subCategoryName}
    [HttpGet("subcategory/{subCategoryName}")]
    public async Task<IActionResult> GetMenuBySubCategoryName(string subCategoryName)
    {
        var menuItems = await _menuItemRepository.GetMenuBySubCategoryName(subCategoryName);
        if (!menuItems.Any())
        {
            return NotFound();
        }
        return Ok(menuItems);
    }

    [HttpGet("restaurant/{restaurantName}")]
    public async Task<IActionResult> GetMenuByRestaurantName(string restaurantName)
    {
        var menuItems = await _menuItemRepository.GetMenuByRestaurantName(restaurantName);

        if (menuItems == null || !menuItems.Any())
        {
            return NotFound($"No menu items found for restaurant: {restaurantName}");
        }

        return Ok(menuItems);
    }


    // GET: api/MenuItems/filter
    [HttpGet("filter")]
    public async Task<IActionResult> GetItemsByFilter(decimal? minPrice,
     decimal? maxPrice,
     string? Type,
     decimal? Rating,
     string? CategoryName,
        string? restaurantname)
    { 
        var menuItems = await _menuItemRepository.GetItemsByFilterAsync(minPrice, maxPrice,Type,Rating, CategoryName,restaurantname);
        return Ok(menuItems);
    }

    // POST: api/MenuItems
    [HttpPost("add")]
    public async Task<IActionResult> Add([FromBody] MenuItem menuItem)
    {
        // Generate a unique MenuItemID (example)
        menuItem.MenuItemID = "M" + new Random().Next(1000, 9999);

        await _menuItemRepository.Add(menuItem);
        return CreatedAtAction(nameof(GetByUId), new { id = menuItem.MenuItemID }, menuItem);
    }

    // PUT: api/MenuItems/{id}
    [HttpPut("update")]
    public async Task<IActionResult> Update( [FromBody] MenuItem menuItem)
    {
      

        await _menuItemRepository.Update(menuItem);
        return NoContent();
    }

    // DELETE: api/MenuItems/{id}
    [HttpDelete("delete/{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        await _menuItemRepository.Delete(id);
        return NoContent();
    }
}
