﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ZomatoApp_API.Entities
{
    public class MenuSubCategory
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string SubCategoryID { get; set; } // Primary Key
        [ForeignKey("MenuCategory")]

        public string MenuCategoryID { get; set; } // Foreign Key to MenuCategory

        [JsonIgnore] public MenuCategory? MenuCategory { get; set; }

        [Column(TypeName = "varchar(50)")]
        [Required]
        public string SubCategoryName { get; set; } // e.g., Chicken, Mutton, etc.

        public string Type {  get; set; } //ex :Veg  & NonVeg

    }
}
