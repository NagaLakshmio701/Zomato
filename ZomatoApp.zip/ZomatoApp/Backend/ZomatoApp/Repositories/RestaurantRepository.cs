﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public class RestaurantRepository : IRestaurantRepository
    {
        private readonly ZomatoAppDBContext _context;

        public RestaurantRepository(ZomatoAppDBContext context)
        {
            _context = context;
        }


        public async Task<Restaurant> GetById(string id)
        {
            return await _context.Restaurants.SingleOrDefaultAsync(f => f.RestaurantID == id);
        }

        public async Task<IEnumerable<Restaurant>> GetByOwnerId(string Ownerid)
        {
            return await _context.Restaurants
                                     .Where(r => r.OwnerID == Ownerid)
                                     .ToListAsync();
        }


        // Asynchronously retrieves menu items by a specific restaurant Name
      /*  public async Task<Restaurant> GetMenuByRestaurantName(string restaurantname)
        {
            return await _context.Restaurants
                                 .Where(mi => mi.RestaurantName == restaurantname)
                                 .ToListAsync();*/

            public async Task<IEnumerable<Restaurant>> GetMenuByRestaurantName(string restaurantName)
            {
                return await _context.Restaurants
                                     .Where(r => r.RestaurantName == restaurantName)
                                     .ToListAsync();
            }

            /*  return await _context.Restaurants
                                  .Include(r => r.User)
                                  .FirstOrDefaultAsync(r => r.RestaurantName == restaurantname);*/
        
        public async Task<IEnumerable<Restaurant>> GetAll()
        {
            return await _context.Restaurants
                                 .Include(r => r.User)
                                 .ToListAsync();
        }

        public async Task Add(Restaurant restaurant)
        {
            await _context.Restaurants.AddAsync(restaurant);
            await _context.SaveChangesAsync();
        }

        public async Task Update(Restaurant restaurant)
        {
            _context.Restaurants.Update(restaurant);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(string id)
        {
            var restaurant = await _context.Restaurants.FindAsync(id);
            if (restaurant != null)
            {
                _context.Restaurants.Remove(restaurant);
                await _context.SaveChangesAsync();
            }
        }



    }
}
