﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public interface IMenuCategoryRepository
    {
        // Asynchronously retrieves all menu categories.
        Task<IEnumerable<MenuCategory>> GetAll();

        // Asynchronously retrieves a menu category by its name.
        Task<MenuCategory> GetByCategoryByName(string categoryName);

        // Asynchronously adds a new menu category.
        Task Add(MenuCategory menuCategory);

        // Asynchronously updates an existing menu category.
        Task Update(MenuCategory menuCategory);

        // Asynchronously deletes a menu category by its ID.
        Task Delete(string categoryID);
    }
}
