﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ZomatoApp_API.Migrations
{
    public partial class ng : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Drop foreign keys if they exist
            migrationBuilder.Sql(
                @"
                IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_BucketLists_Restaurants_RestaurantID')
                BEGIN
                    ALTER TABLE BucketLists DROP CONSTRAINT FK_BucketLists_Restaurants_RestaurantID
                END
                IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Orders_Restaurants_RestaurantID')
                BEGIN
                    ALTER TABLE Orders DROP CONSTRAINT FK_Orders_Restaurants_RestaurantID
                END
                "
            );

          

          

          


         
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PaymentStatus",
                table: "Payments",
                type: "varchar(500)",
                maxLength: 500,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "RestaurantID",
                table: "Orders",
                type: "varchar(50)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "Date",
                table: "BucketLists",
                type: "DateTime",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "RestaurantID",
                table: "BucketLists",
                type: "varchar(50)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_RestaurantID",
                table: "Orders",
                column: "RestaurantID");

            migrationBuilder.CreateIndex(
                name: "IX_BucketLists_RestaurantID",
                table: "BucketLists",
                column: "RestaurantID");

            migrationBuilder.AddForeignKey(
                name: "FK_BucketLists_Restaurants_RestaurantID",
                table: "BucketLists",
                column: "RestaurantID",
                principalTable: "Restaurants",
                principalColumn: "RestaurantID",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Orders_Restaurants_RestaurantID",
                table: "Orders",
                column: "RestaurantID",
                principalTable: "Restaurants",
                principalColumn: "RestaurantID",
                onDelete: ReferentialAction.NoAction);
        }
    }
}
