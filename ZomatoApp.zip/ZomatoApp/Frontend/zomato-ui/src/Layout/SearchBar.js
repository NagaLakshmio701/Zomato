import { useState, useEffect } from 'react';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import axios from 'axios';
import HomeContent from "./HomeItems";
import { isEditable } from '@testing-library/user-event/dist/utils';


const SearchBar = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searchType, setSearchType] = useState('');
  const [restaurantNames, setRestaurantNames] = useState({});
  const [categories, setCategories] = useState([]);
  const [addedItems, setAddedItems] = useState({});


  useEffect(() => {
    const fetchRestaurants = async () => {
      try {
        const response = await axios.get('http://localhost:5141/api/Restaurant/GetAllRestaurants',{
          headers: {
            Authorization:` Bearer ${sessionStorage.getItem("token")}`,
          },
        });
   
        setRestaurantNames(response.data);
        console.log("fechRestaurante",response.data)
      } catch (error) {
        console.error('Error fetching restaurant data:', error);
      }
    };

    fetchRestaurants();
  }, []);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await axios.get('http://localhost:5141/api/MenuCategory/GetAll',{
          headers: {
            Authorization:` Bearer ${sessionStorage.getItem("token")}`,
          },
        });
        setCategories(response.data);
        console.log("fechcategories",response.data)

      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    };

    fetchCategories();
  }, []);

  const search = async () => {
    console.log("Search function called with query:", searchQuery);
    const capitalizeWords = (query) => {
      return query
        .toLowerCase() // Convert the entire query to lowercase
        .split(" ")    // Split the query by spaces to handle each word
        .map(word => word.charAt(0).toUpperCase() + word.slice(1)) // Capitalize the first letter of each word
        .join(" ");    // Join the words back into a single string
    };
    const query = capitalizeWords(searchQuery);

    if (!query) return;

    const { url, type } = determineUrl(query);
    console.log("Determined URL:", url);

    if (url) {
      try {
        const response = await axios.get(url);
        console.log("Search results:", response.data);
      response.data.forEach(item => {
        console.log("item",item);
        console.log("itemdes",`Item: ${item.menuItemID}, Description: ${item.description}`,{
          headers: {
            Authorization:` Bearer ${sessionStorage.getItem("token")}`,
          },
        });  // Check if description is present

       localStorage.setItem(`${item.menuItemID}_description`, item.description);
       localStorage.setItem(`${item.menuItemID}_price`, item.price);})
  
  setSearchResults(response.data);

        setSearchType(type);
        if (type === 'subcategory' || type === 'category') {
          const restaurantIDs = [...new Set(response.data.map(item => item.restaurantID))];
          const names = await fetchRestaurantNames(restaurantIDs);
          setRestaurantNames(names);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    } else {
      console.log("No matching endpoint found.");
      // Consider adding user feedback for no results
    }}

  
  const determineUrl = (query) => {
    if (isRestaurantName(query)) {
      return { url: `http://localhost:5141/api/MenuItems/restaurant/${query}`, type: 'restaurant' };
    } else if (isCategoryName(query)) {
      return { url: `http://localhost:5141/api/MenuItems/category/${query}`, type: 'category' };
    } else {
      return { url: `http://localhost:5141/api/MenuItems/subcategory/${query}`, type: 'subcategory' };
    }
  };

  const isRestaurantName = (name) => {
    return Object.values(restaurantNames).includes(name);
  };

  const isCategoryName = (name) => {
    return categories.some(category => category.categoryName === name);
  };

  const fetchRestaurantNames = async (restaurantIDs) => {
    try {
      const promises = restaurantIDs.map(id =>
        axios.get(`http://localhost:5141/api/Restaurant/GetById/${id}`).then(response => ({
          [id]: response.data.restaurantName
        }))
      );
      const results = await Promise.all(promises);
      return Object.assign({}, ...results);
    } catch (error) {
      console.error('Error fetching restaurant names:', error);
      return {};
    }
  };

  const addToCart=(mid)=>{
 
  const userID = sessionStorage.getItem("userid");

  if (!userID) {
    // If no user is logged in, show an alert and return early
    alert("Please login before adding to cart.");
    return;
  }

  // Fetch the price from session/local storage
  const getPriceFromSession = (menuItemID) => {
    return localStorage.getItem(`${menuItemID}_price`);
  };
    const price = getPriceFromSession(mid);
    let cart={
    bucketListID: "0", // Ensure this is correct or let the server generate it
    userID: sessionStorage.getItem("userid"),
    menuItemID: mid,
    date: new Date(), // Example for current date
    price:price, // Convert to number if needed
    quantity: 1, // Default valup
    totalPrice: parseFloat(price) * 1 // Example calculation
    }
    console.log(cart);
axios.post("http://localhost:5141/api/BucketList/AddBucketList",cart,{
  headers: {
    Authorization: `Bearer ${sessionStorage.getItem("token")}`,
  },
})
.then((response)=>{
  if (response.status === 200) {
    setAddedItems((prevState) => ({
      ...prevState,
      [mid]: true, // Only update the state for the clicked menuItemID
    }));  }console.log(response)}).catch((error)=>console.log(error)) 
}
  
  return (
    <>

      <div className="hero-section text-center text-white" style={{ backgroundImage: 'url(https://www.thedesimasala.net/Assets/images/Branches/img1.png)', padding: '200px 0' ,height:'200px' }}>
        <Container>
          <h2>Discover the best food & drinks in Delhi NCR</h2>
          <Row className="justify-content-center">
            <Col md={6}>
              <div className="input-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search for restaurant or a dish"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="input-group-append">
                  <Button variant="danger" onClick={search}>Search</Button>
                </div>
              </div>
            </Col>
          </Row></Container></div>
          <div className="hero-section text-center text-white" style={{padding:'45px'}}>
        <Container>
          {searchResults.length > 0 ? (
         
            <Row>
              {searchType === 'category' && searchResults.map(item => (
                <Col md={4} key={item.CategoryID}>
                  <Card className="h-100">
                    <Card.Img variant="top" src={"https://www.licious.in/blog/wp-content/uploads/2022/06/chicken-hyderabadi-biryani-01-768x768.jpg"} alt={item.CategoryName} style={{ height: '200px', objectFit: 'cover' }} />
                    <Card.Body>
                      <Card.Title>{item.CategoryName}</Card.Title>
                      <Card.Text>
                        <strong>Price:</strong> {item.price}<br />
                        <strong>Description:</strong> {item.description}<br />
                        <strong>Restaurant:</strong> {restaurantNames[item.restaurantID] || 'Loading...'}
                      </Card.Text>
                      <Button
          key={item.menuItemID}
          variant="primary"
          onClick={() => addToCart(item.menuItemID)}
          disabled={addedItems[item.menuItemID]} // Disable only the clicked item
        >
          {addedItems[item.menuItemID] ? "Added" : "Add to Cart"}
        </Button>               </Card.Body>
                  </Card>
                </Col>
              ))}

              {searchType === 'subcategory' && searchResults.map(item => (
                <Col md={4} key={item.MenuItemID}>
                  <Card className="h-100">
                    <Card.Img variant="top" src={"https://www.licious.in/blog/wp-content/uploads/2022/06/chicken-hyderabadi-biryani-01-768x768.jpg"} alt={item.SubCategoryName} style={{ height: '200px', objectFit: 'cover' }} />
                    <Card.Body>
                      <Card.Title>{item.MenuItemName}</Card.Title>
                      <Card.Text>
                        <strong>Price:</strong> {item.price}<br />
                        <strong>Description:</strong> {item.description}<br />
                        <strong>Restaurant:</strong> {restaurantNames[item.restaurantID] || 'Loading...'}
                      </Card.Text>
                      <Button variant="primary" onClick={()=>addToCart(item.menuItemID)}>Add to Cart</Button>
                    </Card.Body>
                  </Card>
                </Col>
              ))}

              {searchType === 'restaurant' && searchResults.map(item => (
                <Col md={4} key={item.menuItemID}>
                  <Card className="h-100">
                    <Card.Img variant="top" src={"https://www.licious.in/blog/wp-content/uploads/2022/06/chicken-hyderabadi-biryani-01-768x768.jpg"} alt={item.MenuItemName} style={{ height: '200px', objectFit: 'cover' }} />
                    <Card.Body>
                      <Card.Title>{item.MenuItemName}</Card.Title>
                      <Card.Text>
                        <strong>Price:</strong> {item.price}<br />
                        <strong>Description:</strong> {item.description}
                      </Card.Text>
                      <Button variant="primary" onClick={()=>addToCart(item.menuItemID)}>Add to Cart</Button>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
           
          ): (
            <div>
              <HomeContent />
            </div>
          )} 
          </Container>
          </div>
    </>
  );
};

export default SearchBar;
