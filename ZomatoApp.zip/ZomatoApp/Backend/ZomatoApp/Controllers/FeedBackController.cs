﻿

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Repositories;

namespace ZomatoApp_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedBackController : ControllerBase
    {

        private readonly IFeedbackRepository _feedbackRepository;

        public FeedBackController(IFeedbackRepository feedbackRepository)
        {
            _feedbackRepository = feedbackRepository;
        }

        [HttpGet, Route("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                return Ok(await _feedbackRepository.GetAll());
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> GetById([FromRoute] string id)
        {
            try
            {
                var feedback = await _feedbackRepository.GetById(id);
                if (feedback == null)
                {
                    return NotFound();
                }
                return Ok(feedback);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }



        [HttpGet("GetFeedBackBy Rating")]
        public async Task<IActionResult> GetFeedbacksByRating([FromQuery] decimal? minRating, [FromQuery] decimal? maxRating)
        {
            var feedbacks = await _feedbackRepository.GetFeedbacksByRating(minRating, maxRating);
            return Ok(feedbacks);
        }
        [HttpPost, Route("AddFeedback")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Add([FromBody] FeedBack feedback)
        {
            try
            {
                feedback.FeedbackID = "F" + new Random().Next(1000, 9999);

                await _feedbackRepository.Add(feedback);
                return Ok(feedback);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }



        [HttpGet("GetRestaurantFeedBack/{restaurantname}")]
        public async Task<IActionResult> GetFeedbacksByRestaurantAsync(string restaurantname)
        {
            var feedbacks = await _feedbackRepository.GetFeedbacksByRestaurantAsync(restaurantname);

            if (feedbacks == null || !feedbacks.Any())
            {
                return NotFound(new { Message = "No feedbacks found for this restaurant." });
            }

            return Ok(feedbacks);
        }

        [HttpPut, Route("EditFeedback")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Edit([FromBody] FeedBack feedback)
        {
            try 
            {
                await _feedbackRepository.Update(feedback);
                return Ok(feedback);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpDelete, Route("DeleteFeedback/{id}")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Delete([FromRoute] string id)
        {
            try
            {
                await _feedbackRepository.DeleteById(id);
                return Ok();
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }
    }
}

