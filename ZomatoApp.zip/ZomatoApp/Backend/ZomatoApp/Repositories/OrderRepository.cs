﻿using Microsoft.EntityFrameworkCore;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public class OrderRepository:IOrderRepository
    {
     

            private readonly ZomatoAppDBContext _context;

            public OrderRepository(ZomatoAppDBContext context)
            {
                _context = context;
            }

            public async Task Add(Order order)
            {
                await _context.Orders.AddAsync(order);
                await _context.SaveChangesAsync();
            }

        public async Task<List<Order>> GetById(string userId)
        {
            return await _context.Orders
                .Where(o => o.UserID == userId)
                .ToListAsync();
        }

        public async Task<List<Order>> GetAll()
            {
                return await _context.Orders.ToListAsync();
            }


        public async Task<IEnumerable<Order>> GetOrdersByDateRange(DateTime startDate, DateTime endDate)
        {
            return await _context.Orders
                                 .Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate)
                       
                                 .ToListAsync();
        }
        public async Task Update(Order order)
            {
                _context.Orders.Update(order);
                await _context.SaveChangesAsync();
            }


        public async Task<bool> UpdateOrderStatus(string orderId, string newStatus)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order == null)
            {
                return false;
            }

            order.OrderStatus = newStatus;
            _context.Orders.Update(order);
            await _context.SaveChangesAsync();

            return true;
        }
        public async Task DeleteById(string id)
            {
                var order = await _context.Orders.FindAsync(id);
                _context.Orders.Remove(order);
                await _context.SaveChangesAsync();
            }
        }
    }



