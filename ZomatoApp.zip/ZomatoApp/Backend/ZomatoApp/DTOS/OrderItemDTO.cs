﻿namespace ZomatoApp_API.DTOS
{
    public class OrderItemDTO
    {
        public string OrderItemID { get; set; }
        public String UserID { get; set; } // Foreign Key to Users table

        public string ItemName { get; set; }

        public string RestaurantName { get; set; }

        public DateTime Date {  get; set; }





        public double Price { get; set; }

        
        public int Quantity { get; set; }

        public double TotalPrice { get; set; }


    }
}
