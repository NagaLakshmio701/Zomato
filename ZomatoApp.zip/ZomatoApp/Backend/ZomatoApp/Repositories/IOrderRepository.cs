﻿using ZomatoApp_API.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;
/*using ZomatoApp_API.Migrations;
*/
namespace ZomatoApp_API.Repositories
{
    public interface IOrderRepository
    {

        Task Add(Order order);
        Task<List<Order>> GetById(string userId);
        Task<List<Order>> GetAll();
        Task<IEnumerable<Order>> GetOrdersByDateRange(DateTime startDate, DateTime endDate);

        Task<bool> UpdateOrderStatus(string orderId, string newStatus);

        Task Update(Order order);
        Task DeleteById(string id);


    }
}

