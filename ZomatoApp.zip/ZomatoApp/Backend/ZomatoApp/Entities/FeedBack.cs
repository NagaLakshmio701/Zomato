﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ZomatoApp_API.Entities
{
    public class FeedBack
    {
        [Key]
        [Required]
        [Column(TypeName = "varchar(50)")]
        public string FeedbackID { get; set; } // Primary Key as String

        [ForeignKey("User")]

        [Required]

        [Column(TypeName = "varchar(50)")]
        public string UserID { get; set; } // Foreign Key to Users table

        [JsonIgnore]
        public User? User { get; set; }

        [ForeignKey("Restaurant")]

        [Required]
        [Column(TypeName = "varchar(50)")]

        public string RestaurantID { get; set; } // Foreign Key to Restaurants table

        [JsonIgnore]
        public Restaurant? Restaurant { get; set; }

        [Required]
        [MaxLength(1000)]
        public string Comments { get; set; } // Feedback comments

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Rating { get; set; } // Rating out of 5

        [Required]
        [Column(TypeName = "DateTime")]
        public DateTime FeedbackDate { get; set; } // Date when feedback was given
    }
}
