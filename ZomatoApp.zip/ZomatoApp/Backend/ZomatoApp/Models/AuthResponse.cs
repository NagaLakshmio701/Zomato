﻿namespace ZomatoApp_API.Models
{
    public class AuthResponse
    {
        public string UserID { get; set; }

        public string Name { get; set; }

        public string Role { get; set; }
        public string Token { get; set; }
    }
}
