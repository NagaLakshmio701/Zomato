import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const ManageTransactions = () => {
  const [transactions, setTransactions] = useState([]);
  const [userId, setUserId] = useState("U0002"); // Default user ID or fetch from session storage
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch all transactions on component mount
    axios
      .get("http://localhost:5141/api/Payment/GetAll", {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        setTransactions(response.data);
        setLoading(false);
      })
      .catch((error) => console.log(error));
  }, []);

  const handleUserTransactions = () => {
    // Fetch transactions by user ID
    axios
      .get(`http://localhost:5141/api/Payment/GetById/${userId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        setTransactions(response.data);
      })
      .catch((error) => console.log(error));
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Manage Transactions</h2>
      
      <div className="mb-4">
        <div className="form-group">
          <label htmlFor="userId" className="form-label">User ID</label>
          <input
            id="userId"
            type="text"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            className="form-control"
          />
        </div>
        <button
          type="button"
          onClick={handleUserTransactions}
          className="btn btn-primary mt-3"
        >
          Fetch User Transactions
        </button>
      </div>

      <div className="table-responsive">
        <table className="table table-striped table-bordered table-hover">
          <thead className="table-dark">
            <tr>
              <th>Payment ID</th>
              <th>Order ID</th>
              <th>User ID</th>
              <th>Payment Method</th>
              <th>Total Amount</th>
              <th>Payment Date</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction) => (
              <tr key={transaction.paymentID}>
                <td>{transaction.paymentID}</td>
                <td>{transaction.orderID}</td>
                <td>{transaction.userID}</td>
                <td>{transaction.paymentMethod}</td>
                <td>{transaction.totalAmount}</td>
                <td>{new Date(transaction.paymentDate).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ManageTransactions;
