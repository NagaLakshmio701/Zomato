import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const UpdateRestaurantProfile = () => {
  const [restaurants, setRestaurants] = useState([]);
  const navigate = useNavigate();
  const ownerId = "W0002"; // Replace with dynamic value if necessary

  useEffect(() => {
    axios
      .get(`http://localhost:5141/api/Restaurant/GetRestaurantByOwnerId/${ownerId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        setRestaurants(response.data);
      })
      .catch((error) => console.log(error));
  }, [ownerId]);

  const handleDelete = (restaurantId) => {
    axios
      .delete(`http://localhost:5141/api/Restaurant/DeleteRestaurant/${restaurantId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        setRestaurants(restaurants.filter(r => r.restaurantID !== restaurantId));
      })
      .catch((error) => console.log(error));
  };

  const handleUpdate = (restaurantId) => {
    sessionStorage.setItem("RestID", restaurantId);
    navigate("/admin-dashboard/update-restaurant");
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Manage Restaurants</h2>
      <table className="table table-striped table-bordered table-hover">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Location</th>
            <th>Phone Number</th>
            <th>Rating</th>
            <th>Opening Time</th>
            <th>Closing Time</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {restaurants.map((restaurant) => (
            <tr key={restaurant.restaurantID}>
              <td>{restaurant.restaurantID}</td>
              <td>{restaurant.restaurantName}</td>
              <td>{restaurant.location}</td>
              <td>{restaurant.phoneNumber}</td>
              <td>{restaurant.rating}</td>
              <td>{restaurant.openingTime}</td>
              <td>{restaurant.closingTime}</td>
              <td>
                <button 
                  className="btn btn-warning btn-sm me-2" 
                  onClick={() => handleUpdate(restaurant.restaurantID)}
                >
                  Update
                </button>
                <button 
                  className="btn btn-danger btn-sm" 
                  onClick={() => handleDelete(restaurant.restaurantID)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UpdateRestaurantProfile;
