﻿using ZomatoApp_API.Entities;
using ZomatoApp_API.DTOS;

namespace ZomatoApp_API.Repositories
{
    public interface IOrderItemRepository
    {

        Task<IEnumerable<OrderItem>> GetAllOrderItems();
        Task<List<OrderItemDTO>> GetOrderItemByUserId(string UserId); // Corrected to return Task<List<OrderItemDTO>>
        Task AddOrderItem(OrderItem orderItem);
        Task UpdateOrderItem(OrderItem orderItem);
        Task DeleteOrderItem(int orderItemId);


    }
}
