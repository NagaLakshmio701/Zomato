import { Navbar, Nav, Container } from 'react-bootstrap';
import { Link } from "react-router-dom";

const Header = () => {
    const user = JSON.parse(sessionStorage.getItem('user'));

    return (
        <>
            <Navbar bg="light" expand="lg" style={{ padding: '30px 0', fontSize: '30px ' }}>
                <Container>
                    <Navbar.Brand className="mx-auto order-0">
                        <h1 style={{ display: 'inline', margin: 0 }}>Zomato</h1>
                    </Navbar.Brand>
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="ml-auto ms-auto order-1 order-lg-2">
                            {user ? (
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                    <h2 style={{ margin: '0 15px 0 0' }}>Welcome, {user.name}</h2>
                                    <Nav>
                                        <Nav.Link as={Link} to="/profile" style={{ fontSize: '1.2rem', marginRight: '15px' }}>
                                            Profile
                                        </Nav.Link>
                                        <Nav.Link as={Link} to="/logout" style={{ fontSize: '1.2rem' }}>
                                            Logout
                                        </Nav.Link>
                                        {/* Conditionally render 'View Cart' only when role is 'user' */}
                                        {user.role === 'User' && (
                                            <Nav.Link as={Link} to="/viewcart" style={{ fontSize: '1.2rem' }}>
                                                Your Cart
                                            </Nav.Link>
                                        )}
                                    </Nav>
                                </div>
                            ) : (
                                <>
                                    <Nav.Link as={Link} to="/login">Login</Nav.Link>
                                    <Nav.Link as={Link} to="/register">Signup</Nav.Link>
                                </>
                            )}
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </>
    );
}

export default Header;
