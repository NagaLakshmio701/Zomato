import React from 'react';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import { FaStore, FaUser, FaClipboardList, FaCommentDots, FaTruck, FaMoneyCheckAlt } from 'react-icons/fa';

const AdminDashboard = () => {
  return (
    <Container className="mt-5">
      <h2 className="text-center mb-4">Admin Dashboard</h2>
      <Row className="gy-4">
        <Col md={4}>
          <Card className="shadow-lg border-0">
            <Card.Body className="text-center">
              <FaStore size={40} className="mb-3" />
              <Card.Title className="mb-2">Manage Restaurants</Card.Title>
              <Card.Text className="text-muted">Add, edit, or delete restaurant details.</Card.Text>
              <Button variant="primary" href="/manage-restaurants">
                Manage Restaurants
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card className="shadow-lg border-0">
            <Card.Body className="text-center">
              <FaUser size={40} className="mb-3" />
              <Card.Title className="mb-2">Manage Users</Card.Title>
              <Card.Text className="text-muted">Add, edit, or delete users.</Card.Text>
              <Button variant="primary" href="/manage-users">
                Manage Users
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card className="shadow-lg border-0">
            <Card.Body className="text-center">
              <FaClipboardList size={40} className="mb-3" />
              <Card.Title className="mb-2">View Orders</Card.Title>
              <Card.Text className="text-muted">Track and manage customer orders.</Card.Text>
              <Button variant="primary" href="/view-orders">
                View Orders
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card className="shadow-lg border-0">
            <Card.Body className="text-center">
              <FaCommentDots size={40} className="mb-3" />
              <Card.Title className="mb-2">Customer Feedback</Card.Title>
              <Card.Text className="text-muted">Review customer feedback and ratings.</Card.Text>
              <Button variant="primary" href="/view-feedback">
                View Feedback
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card className="shadow-lg border-0">
            <Card.Body className="text-center">
              <FaTruck size={40} className="mb-3" />
              <Card.Title className="mb-2">Manage Delivery Personnel</Card.Title>
              <Card.Text className="text-muted">Add, edit, or delete Delivery Personnel.</Card.Text>
              <Button variant="primary" href="/view-deliverypersonnel">
                View Delivery Personnel Details
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card className="shadow-lg border-0">
            <Card.Body className="text-center">
              <FaMoneyCheckAlt size={40} className="mb-3" />
              <Card.Title className="mb-2">Manage Transactions</Card.Title>
              <Card.Text className="text-muted">Review and update transactions.</Card.Text>
              <Button variant="primary" href="/view-transactions">
                View Transactions
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default AdminDashboard;
