﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public interface IDeliveryPersonnelRepository
    {
        Task Add(DeliveryPersonnel deliveryPersonnel);
        Task<DeliveryPersonnel> GetById(string id);
        Task<List<DeliveryPersonnel>> GetAll();
        Task Update(DeliveryPersonnel deliveryPersonnel);
        Task DeleteById(string id);
    }
}
