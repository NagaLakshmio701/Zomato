﻿using Microsoft.EntityFrameworkCore;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public class PaymentRepository : IPaymentRepository
    {

        private readonly ZomatoAppDBContext _context;

        public PaymentRepository(ZomatoAppDBContext context)
        {
            _context = context;
        }

        public async Task Add(Payment payment)
        {
            await _context.Payments.AddAsync(payment);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Payment>> GetById(string Uid)
        {

            return await _context.Payments
                .Where(o => o.UserID == Uid)
                .ToListAsync();
        }

        public async Task<List<Payment>> GetAll()
        {
            return await _context.Payments.ToListAsync();
        }

        public async Task Update(Payment payment)
        {
            _context.Payments.Update(payment);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteById(string id)
        {
            var payment = await _context.Payments.FindAsync(id);
            _context.Payments.Remove(payment);
            await _context.SaveChangesAsync();
        }

    }
}


