import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Button, Card, Form, Alert } from "react-bootstrap";

const DeliveryPersonnelManager = () => {
  const [personnel, setPersonnel] = useState([]);
  const [selectedPersonnel, setSelectedPersonnel] = useState(null);
  const [formState, setFormState] = useState({
    deliveryPersonnelID: '',
    email: '',
    password: '',
    phoneNumber: '',
    name: ''
  });
  const [mode, setMode] = useState('list'); // 'list', 'add', 'update'
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (mode === 'list') {
      axios
        .get("http://localhost:5141/api/DeliveryPersonnel/GetAll", {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          },
        })
        .then((response) => setPersonnel(response.data))
        .catch((error) => setError("Failed to fetch delivery personnel."));
    } else if (mode === 'update' && selectedPersonnel) {
      axios
        .get(`http://localhost:5141/api/DeliveryPersonnel/GetAll/${selectedPersonnel.deliveryPersonnelID}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          },
        })
        .then((response) => setFormState(response.data))
        .catch((error) => setError("Failed to fetch personnel details."));
    }
  }, [mode, selectedPersonnel]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormState((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAdd = () => {
    axios
      .post("http://localhost:5141/api/DeliveryPersonnel/AddDeliveryPersonnel", formState, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        alert("Delivery personnel added successfully!");
        setMode('list');
      })
      .catch((error) => setError("Failed to add delivery personnel."));
  };

  const handleUpdate = () => {
    axios
      .put("http://localhost:5141/api/DeliveryPersonnel/EditDeliveryPersonnel", formState, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        alert("Delivery personnel updated successfully!");
        setMode('list');
      })
      .catch((error) => setError("Failed to update delivery personnel."));
  };

  const handleDelete = (id) => {
    axios
      .delete(`http://localhost:5141/api/DeliveryPersonnel/DeleteDeliveryPersonnel/${id}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => setPersonnel((prev) => prev.filter((p) => p.deliveryPersonnelID !== id)))
      .catch((error) => setError("Failed to delete delivery personnel."));
  };

  return (
    <div className="container mt-4">
      {error && <Alert variant="danger">{error}</Alert>}
      
      {mode === 'list' && (
        <>
          <h2 className="mb-4">Delivery Personnel</h2>
          <Button className="mb-3" variant="primary" onClick={() => setMode('add')}>
            Add Delivery Personnel
          </Button>
          <div className="row">
            {personnel.map((p) => (
              <div className="col-md-4 mb-3" key={p.deliveryPersonnelID}>
                <Card>
                  <Card.Body>
                    <Card.Title>{p.name}</Card.Title>
                    <Card.Subtitle className="mb-2 text-muted">{p.email}</Card.Subtitle>
                    <Card.Text>Phone Number: {p.phoneNumber}</Card.Text>
                    <Button
                      variant="warning"
                      onClick={() => { setSelectedPersonnel(p); setMode('update'); }}
                    >
                      Update
                    </Button>
                    <Button
                      variant="danger"
                      className="ms-2"
                      onClick={() => handleDelete(p.deliveryPersonnelID)}
                    >
                      Delete
                    </Button>
                  </Card.Body>
                </Card>
              </div>
            ))}
          </div>
        </>
      )}

      {(mode === 'add' || mode === 'update') && (
        <Card className="mt-4">
          <Card.Header>{mode === 'add' ? 'Add Delivery Personnel' : 'Update Delivery Personnel'}</Card.Header>
          <Card.Body>
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>ID</Form.Label>
                <Form.Control
                  type="text"
                  name="deliveryPersonnelID"
                  value={formState.deliveryPersonnelID || ''}
                  onChange={handleChange}
                  disabled={mode === 'update'}
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  value={formState.name || ''}
                  onChange={handleChange}
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="email"
                  name="email"
                  value={formState.email || ''}
                  onChange={handleChange}
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Phone Number</Form.Label>
                <Form.Control
                  type="text"
                  name="phoneNumber"
                  value={formState.phoneNumber || ''}
                  onChange={handleChange}
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  name="password"
                  value={formState.password || ''}
                  onChange={handleChange}
                />
              </Form.Group>
              <Button
                variant="primary"
                onClick={mode === 'add' ? handleAdd : handleUpdate}
              >
                {mode === 'add' ? 'Add' : 'Save'}
              </Button>
              <Button
                variant="secondary"
                className="ms-2"
                onClick={() => setMode('list')}
              >
                Cancel
              </Button>
            </Form>
          </Card.Body>
        </Card>
      )}
    </div>
  );
};

export default DeliveryPersonnelManager;
