﻿using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public interface IPaymentRepository
    {

        Task Add(Payment payment);
        Task<List<Payment>> GetById(string uid);
        Task<List<Payment>> GetAll();
        Task Update(Payment payment);
        Task DeleteById(string id);

    }
}

