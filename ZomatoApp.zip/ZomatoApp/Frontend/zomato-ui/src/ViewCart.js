import axios from "axios";
import { useEffect, useReducer,useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Table, Container, Alert, Spinner } from "react-bootstrap";
import './ViewCart.css'; // Assuming you have a CSS file for additional styling

// Reducer function to manage cart state
const cartReducer = (state, action) => {
  switch (action.type) {
    case "SET_ITEMS":
      return {
        ...state,
        items: action.payload,
        totalPrice: action.payload.reduce((acc, item) => acc + item.price * item.quantity, 0),
      };
    case "INCREASE_QUANTITY":
      return {
        ...state,
        items: state.items.map((item) =>
          item.menuItemID === action.payload
            ? { ...item, quantity: item.quantity + 1 }
            : item
        ),
        totalPrice: state.totalPrice + state.items.find(item => item.menuItemID === action.payload).price,
      };
    case "DECREASE_QUANTITY":
      return {
        ...state,
        items: state.items.map((item) =>
          item.menuItemID === action.payload && item.quantity > 1
            ? { ...item, quantity: item.quantity - 1 }
            : item
        ),
        totalPrice: state.totalPrice - state.items.find(item => item.menuItemID === action.payload).price,
      };
    case "REMOVE_ITEM":
      const filteredItems = state.items.filter(item => item.bucketListID !== action.payload);
      return {
        ...state,
        items: filteredItems,
        totalPrice: filteredItems.reduce((acc, item) => acc + item.price * item.quantity, 0),
      };
    default:
      return state;
  }
};

const ViewCart = () => {
  const navigate = useNavigate();
  const [state, dispatch] = useReducer(cartReducer, { items: [], totalPrice: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (sessionStorage.getItem("token") === null) {
      navigate("/login");
    }
  }, [navigate]);

  useEffect(() => {
    const UserId = sessionStorage.getItem("userid");
    axios
      .get(`http://localhost:5141/api/BucketList/GetBucketListByUserID/${UserId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        dispatch({ type: "SET_ITEMS", payload: response.data });
        setLoading(false);
      })
      .catch((error) => {
        setError("Failed to load cart items.");
        setLoading(false);
      });
  }, []);

  const removeCartItem = (cartId) => {
    axios
      .delete(`http://localhost:5141/api/BucketList/DeleteBucketList/${cartId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        dispatch({ type: "REMOVE_ITEM", payload: cartId });
      })
      .catch((err) => console.log(err));
  };

  const AddOrder = () => {
    const order = {
      orderId: "0",
      userId: sessionStorage.getItem("userid"),
      orderDate: new Date(),
      orderStatus: "Pending",
      totalPrice: state.totalPrice,
    };

    if (state.totalPrice > 0) {
      axios
        .post("http://localhost:5141/api/Orders/AddOrder", order, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          },
        })
        .then((response) => {
          const orderId = response.data.orderID;
          localStorage.setItem("oid", orderId);
          localStorage.setItem("totalPrice", response.data.totalPrice);

          state.items.forEach((item) => {
            AddOrderItem(item, orderId);
          });

          const userId = sessionStorage.getItem("userid");
          axios
            .delete(`http://localhost:5141/api/BucketList/DeleteBucketListByUserId/${userId}`, {
              headers: {
                Authorization: `Bearer ${sessionStorage.getItem("token")}`,
              },
            })
            .then(() => {
              navigate("/tran");
            })
            .catch((deleteError) => {
              setError("Error deleting BucketList.");
            });
        })
        .catch((error) => setError("Error placing order."));
    } else {
      alert("Cart items are empty. Please add items to your cart.");
    }
  };

  const AddOrderItem = (item, orderId) => {
    const orderItem = {
      orderitemID: "0",
      orderId: orderId,
      menuItemID: item.menuItemID,
      quantity: item.quantity,
      price: item.price,
      totalPrice: state.totalPrice,
      userId: sessionStorage.getItem("userid"),
      orderDate: new Date(),
    };

    axios
      .post("http://localhost:5141/api/OrderItem/Add", orderItem, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        console.log("AddOrderItem Response:", response);
      })
      .catch((error) => console.log(error));
  };

  if (loading) return <Spinner animation="border" />;

  return (
    <Container className="mt-5">
      {error && <Alert variant="danger">{error}</Alert>}
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>MenuItemId</th>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total Price</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {state.items.map((cart) => (
            <tr key={cart.bucketListID}>
              <td>{cart.menuItemID}</td>
              <td>{localStorage.getItem(`${cart.menuItemID}_description`)}</td>
              <td>{cart.price}</td>
              <td>
                <Button 
                  variant="outline-secondary" 
                  onClick={() => dispatch({ type: "DECREASE_QUANTITY", payload: cart.menuItemID })}
                >
                  -
                </Button>
                {cart.quantity}
                <Button 
                  variant="outline-secondary" 
                  onClick={() => dispatch({ type: "INCREASE_QUANTITY", payload: cart.menuItemID })}
                >
                  +
                </Button>
              </td>
              <td>{cart.price * cart.quantity}</td>
              <td>
                <Button 
                  variant="danger" 
                  onClick={() => removeCartItem(cart.bucketListID)}
                >
                  Remove
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
      <div className="mb-3">Total Price: {state.totalPrice}</div>
      <Button 
        variant="primary" 
        onClick={AddOrder}
      >
        Make Order
      </Button>
    </Container>
  );
};

export default ViewCart;
