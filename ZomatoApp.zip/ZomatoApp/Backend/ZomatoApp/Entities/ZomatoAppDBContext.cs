﻿using System.Collections.Generic;
using System.Reflection.Emit;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Entities
{
    public class ZomatoAppDBContext : DbContext
    {

        public IConfiguration configuration;

        public ZomatoAppDBContext(IConfiguration configuration)
        {

            this.configuration = configuration;
        }
        public DbSet<User> Users { get; set; }
        public DbSet<Restaurant> Restaurants { get; set; }

        public DbSet<MenuItem> MenuItems { get; set; }

        public DbSet<Order> Orders { get; set; }

        public DbSet<DeliveryPersonnel>DeliveryPersonnels { get; set; }

        public DbSet<Payment>Payments { get; set; }
        public DbSet<BucketList> BucketLists { get; set; }

        public DbSet<FeedBack>FeedBacks { get; set; }

        public DbSet<MenuCategory>MenuCategories { get; set; }

        public DbSet<MenuSubCategory>MenuSubCategories { get; set; }

        public DbSet<OrderItem> OrderItems { get; set; }






        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            modelBuilder.Entity<Restaurant>()
              .HasIndex(u => u.RestaurantName)
              .IsUnique();

        }





        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                optionsBuilder.UseSqlServer(configuration.GetConnectionString("ZomatoConnection"));
            }
    }
}
