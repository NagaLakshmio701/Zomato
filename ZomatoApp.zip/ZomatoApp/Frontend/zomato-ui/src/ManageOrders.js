import { useState, useEffect } from "react";
import axios from "axios";
import './OrderManagement.css'; // Import the CSS file

const OrderManagement = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userID, setUserID] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [orderStatus, setOrderStatus] = useState('');
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    // Fetch all orders initially
    axios
      .get("http://localhost:5141/api/Orders/GetAll", {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        setOrders(response.data);
        setLoading(false);
      })
      .catch((error) => console.log(error));
  }, []);

  const handleGetByUserID = () => {
    axios
      .get(`http://localhost:5141/api/Orders/GetById/${userID}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => setOrders(response.data))
      .catch((error) => console.log(error));
  };

  const handleGetByDateRange = () => {
    axios
      .get(`http://localhost:5141/api/Orders/GetByDateRange`, {
        params: { startDate, endDate },
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => setOrders(response.data))
      .catch((error) => console.log(error));
  };

  const handleUpdateOrderStatus = (orderID, newStatus) => {
    setUpdating(true);
    axios
      .put(`http://localhost:5141/api/Orders/${orderID}/UpdateOrderstatus`,`"${newStatus}"`, // Send as JSON
        {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
            'Content-Type': 'application/json'
          }
        }
      )
      .then(() => {
        // Update the local state with the new status
        setOrders((prevOrders) =>
          prevOrders.map((order) =>
            order.orderID === orderID ? { ...order, orderStatus: newStatus } : order
          )
        );
        alert("Order status updated successfully!");
      })
      .catch((error) => {
        console.error("Error updating order status:", error.response ? error.response.data : error.message);
      })
      .finally(() => setUpdating(false)); // Reset updating state
  };
  
  if (loading) return <p>Loading...</p>;

  return (
    <div className="container">
      <h2>Order Management</h2>

      {/* Filter by User ID */}
      <div className="mb-3">
        <label>User ID</label>
        <input
          type="text"
          value={userID}
          onChange={(e) => setUserID(e.target.value)}
          className="form-control"
        />
        <button onClick={handleGetByUserID} className="btn btn-primary mt-2">
          Get Orders by User ID
        </button>
      </div>

      {/* Filter by Date Range */}
      <div className="mb-3">
        <label>Start Date</label>
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          className="form-control"
        />
        <label>End Date</label>
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          className="form-control"
        />
        <button onClick={handleGetByDateRange} className="btn btn-primary mt-2">
          Get Orders by Date Range
        </button>
      </div>

      {/* Orders Table */}
      <table className="table table-bordered table-hover">
        <thead className="table-primary">
          <tr>
            <th>Order ID</th>
            <th>User ID</th>
            <th>Total Price</th>
            <th>Order Date</th>
            <th>Order Status</th>
            <th>Update Status</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.orderID}>
              <td>{order.orderID}</td>
              <td>{order.userID}</td>
              <td>{order.totalPrice}</td>
              <td>{new Date(order.orderDate).toLocaleString()}</td>
              <td>{order.orderStatus}</td>
              <td>
                <button 
                  onClick={() => handleUpdateOrderStatus(order.orderID, 'Delivered')} 
                  className="btn btn-success"
                  disabled={updating}
                >
                  Mark as Completed
                </button>
                <button 
                  onClick={() => handleUpdateOrderStatus(order.orderID, 'Cancelled')} 
                  className="btn btn-danger ms-2"
                  disabled={updating}
                >
                  Mark as Cancelled
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrderManagement;
