﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ZomatoApp_API.Migrations
{
    /// <inheritdoc />
    public partial class m2311 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "DeliveryPersonnels",
                type: "varchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Password",
                table: "DeliveryPersonnels",
                type: "varchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "PhoneNumber",
                table: "DeliveryPersonnels",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Email",
                table: "DeliveryPersonnels");

            migrationBuilder.DropColumn(
                name: "Password",
                table: "DeliveryPersonnels");

            migrationBuilder.DropColumn(
                name: "PhoneNumber",
                table: "DeliveryPersonnels");
        }
    }
}
