﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public class MenuCategoryRepository : IMenuCategoryRepository
    {
        private readonly ZomatoAppDBContext _context;

        public MenuCategoryRepository(ZomatoAppDBContext context)
        {
            _context = context;
        }

        // Asynchronously retrieves all menu categories.
        public async Task<IEnumerable<MenuCategory>> GetAll()
        {
            return await _context.MenuCategories.ToListAsync();
        }

        // Asynchronously retrieves a menu category by its name.
        public async Task<MenuCategory> GetByCategoryByName(string categoryName)
        {
            return await _context.MenuCategories
                                 .FirstOrDefaultAsync(mc => mc.CategoryName == categoryName);
        }

        // Asynchronously adds a new menu category.
        public async Task Add(MenuCategory menuCategory)
        {
            await _context.MenuCategories.AddAsync(menuCategory);
            await _context.SaveChangesAsync();
        }

        // Asynchronously updates an existing menu category.
        public async Task Update(MenuCategory menuCategory)
        {
            _context.MenuCategories.Update(menuCategory);
            await _context.SaveChangesAsync();
        }

        // Asynchronously deletes a menu category by its ID.
        public async Task Delete(string categoryID)
        {
            var menuCategory = await _context.MenuCategories.FindAsync(categoryID);
            if (menuCategory != null)
            {
                _context.MenuCategories.Remove(menuCategory);
                await _context.SaveChangesAsync();
            }
        }
    }
}
