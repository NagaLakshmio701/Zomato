﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public class MenuSubCategoryRepository : IMenuSubCategoryRepository
    {
        private readonly ZomatoAppDBContext _context;

        public MenuSubCategoryRepository(ZomatoAppDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<MenuSubCategory>> GetAll()
        {
            return await _context.MenuSubCategories.ToListAsync();
        }

        public async Task<MenuSubCategory> GetBySubCategoryName(string subCategoryName)
        {
            return await _context.MenuSubCategories
                                 .FirstOrDefaultAsync(msc => msc.SubCategoryName == subCategoryName);
        }

        public async Task<IEnumerable<MenuSubCategory>> GetByCategoryName(string CategoryName)
        {
            return await _context.MenuSubCategories
                .Include(sc => sc.MenuCategory)
                .Where(sc => sc.MenuCategory.CategoryName == CategoryName)
                .ToListAsync();
        }



        public async Task Add(MenuSubCategory menuSubCategory)
        {
            await _context.MenuSubCategories.AddAsync(menuSubCategory);
            await _context.SaveChangesAsync();
        }

        public async Task Update(MenuSubCategory menuSubCategory)
        {
            _context.MenuSubCategories.Update(menuSubCategory);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(string subCategoryID)
        {
            var subCategory = await _context.MenuSubCategories.FindAsync(subCategoryID);
            if (subCategory != null)
            {
                _context.MenuSubCategories.Remove(subCategory);
                await _context.SaveChangesAsync();
            }
        }
    }
}
