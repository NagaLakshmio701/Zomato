import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Button, Table, Container } from "react-bootstrap";
import './ManageRestaurants.css'; // Assuming you're adding custom CSS here

const ManageRestaurants = () => {
  const [restaurants, setRestaurants] = useState([]);
  const navigate = useNavigate();
  const ownerId = sessionStorage.getItem("userid");

  useEffect(() => {
    axios
      .get(`http://localhost:5141/api/Restaurant/GetRestaurantByOwnerId/${ownerId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        setRestaurants(response.data);
      })
      .catch((error) => console.log(error));
  }, [ownerId]);

  const handleDelete = (restaurantId) => {
    axios
      .delete(`http://localhost:5141/api/Restaurant/DeleteRestaurant/${restaurantId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        setRestaurants(restaurants.filter(r => r.restaurantID !== restaurantId));
      })
      .catch((error) => console.log(error));
  };

  const handleUpdate = (restaurantId) => {
    sessionStorage.setItem("RestID", restaurantId);
    navigate("/admin-dashboard/update-restaurant");
  };

  return (
    <Container className="mt-5">
      <h2 className="mb-4">Manage Restaurants</h2>
      <Table striped bordered hover className="shadow-sm">
        <thead className="table-primary">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Location</th>
            <th>Phone Number</th>
            <th>Rating</th>
            <th>Opening Time</th>
            <th>Closing Time</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {restaurants.map((restaurant) => (
            <tr key={restaurant.restaurantID}>
              <td>{restaurant.restaurantID}</td>
              <td>{restaurant.restaurantName}</td>
              <td>{restaurant.location}</td>
              <td>{restaurant.phoneNumber}</td>
              <td>{restaurant.rating}</td>
              <td>{restaurant.openingTime}</td>
              <td>{restaurant.closingTime}</td>
              <td>
                <Button 
                  variant="warning" 
                  className="me-2" 
                  onClick={() => handleUpdate(restaurant.restaurantID)}
                >
                  Update
                </Button>
                <Button 
                  variant="danger" 
                  onClick={() => handleDelete(restaurant.restaurantID)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  );
};

export default ManageRestaurants;
