
using ZomatoApp_API.Repositories;
using ZomatoApp_API.Entities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using static Microsoft.AspNetCore.Mvc.Filters.IFilterMetadata;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.OpenApi.Models;


namespace ZomatoApp_API
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddDbContext<ZomatoAppDBContext>();
            builder.Services.AddTransient<IUserRepository, UserRepository>();
            builder.Services.AddTransient<IRestaurantRepository, RestaurantRepository>();
            builder.Services.AddTransient<IOrderRepository, OrderRepository>();
            builder.Services.AddTransient<IFeedbackRepository, FeedBackRepository>();
            builder.Services.AddTransient<IMenuItemRepository, MenuItemRepository>();

            builder.Services.AddTransient<IDeliveryPersonnelRepository, DeliveryPersonnelRepository>();
            builder.Services.AddTransient<IPaymentRepository, PaymentRepository>();

            builder.Services.AddTransient<IBucketListRepository, BucketListRepository>();
            builder.Services.AddTransient<IMenuCategoryRepository, MenuCategoryRepository>();
            builder.Services.AddTransient<IMenuSubCategoryRepository, MenuSubCategoryRepository>();

            builder.Services.AddTransient<IOrderItemRepository, OrderItemRepository>();








            // Use typeof(GlobalExceptionFilter) to pass the filter as a type
            builder.Services.AddControllers(options => options.Filters.Add(typeof(GlobalExceptionFilter)));
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            //CONFIGURE THE CORS 
            builder.Services.AddCors(c =>
            {
                c.AddPolicy("AllowOrigin", options => options.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
            }); 

            //Configure JWT to valid token data
            #region TokenValidationCode
            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(o =>
            {
                o.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidIssuer = builder.Configuration["Jwt:Issuer"],
                    ValidAudience = builder.Configuration["Jwt:Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"])),
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = false,
                    ValidateIssuerSigningKey = true
                };
            });
            #endregion

            //Configure Swagger UI to validate token
            #region Swagger UI for Validate Token
            builder.Services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "JWTToken_Auth_API",
                    Version = "v1"
                });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 1safsfsdfdfd\"",
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement {
        {
            new OpenApiSecurityScheme {
                Reference = new OpenApiReference {
                    Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
            });
            #endregion

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();

/*                app.UseDeveloperExceptionPage();
*/                //app.UseExceptionHandler("/error");
            }
           

            //ADD CORS TO MIDDLEWARE
            app.UseCors("AllowOrigin");
            app.UseAuthentication();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
