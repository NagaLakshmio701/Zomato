import { Navbar, Nav,Container, Row, Col, Button, Card } from 'react-bootstrap';

const Footer=()=>{

return (
 <>  
<footer className="bg-light py-5">
        <Container>
          <Row>
            <Col md={3}>
              <h5>About Zomato</h5>
              <ul className="list-unstyled">
                <li>Who We Are</li>
                <li>Blog</li>
                <li>Work With Us</li>
                <li>Investor Relations</li>
                <li>Report Fraud</li>
              </ul>
            </Col>
            <Col md={3}>
              <h5>For Restaurants</h5>
              <ul className="list-unstyled">
                <li>Add restaurant</li>
                <li>Business App</li>
              </ul>
            </Col>
            <Col md={3}>
              <h5>Learn More</h5>
              <ul className="list-unstyled">
                <li>Privacy</li>
                <li>Terms</li>
                <li>Security</li>
              </ul>
            </Col>
            <Col md={3}>
              <h5 className="mb-4">Social Links</h5>
              <ul className="list-unstyled d-flex justify-content-center mb-4">
                <li className="me-3">
                  <a href="#!"><i className="bi bi-facebook"></i></a>
                </li>
                <li className="me-3">
                  <a href="#!"><i className="bi bi-twitter"></i></a>
                </li>
                <li className="me-3">
                  <a href="#!"><i className="bi bi-instagram"></i></a>
                </li>
              </ul>

              <h5 className="mb-4">Get the App</h5>
              <div className="d-flex justify-content-center gap-3">
                <a href="#!" className="d-flex align-items-center text-decoration-none">
                  <i className="bi bi-google-play" style={{ fontSize: '1rem', color: '#34b7f1' }}></i>
                  <span className="ms-2" style={{ fontSize: '1rem', color: '#34b7f1' }}>Google Play Store</span>
                </a>
                <a href="#!" className="d-flex align-items-center text-decoration-none">
                  <i className="bi bi-apple" style={{ fontSize: '1rem', color: '#34b7f1' }}></i>
                  <span className="ms-2" style={{ fontSize: '1rem', color: '#34b7f1' }}>Apple App Store</span>
                </a>
              </div>
            </Col>
          </Row>
          <Row className="pt-3">
            <Col md={12} className="text-center">
              <p>&copy; {new Date().getFullYear()} Zomato. All rights reserved.</p>
            </Col>
          </Row>
        </Container>
      </footer>
    </>
)
}

export default Footer;