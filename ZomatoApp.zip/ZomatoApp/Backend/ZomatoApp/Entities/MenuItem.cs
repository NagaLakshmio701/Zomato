﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ZomatoApp_API.Entities
{
    public class MenuItem
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string MenuItemID { get; set; }

        [Required]
        [Column(TypeName = "varchar(50)")]
        [ForeignKey("Restaurant")] // Foreign Key to Restaurants table

        public string RestaurantID { get; set; }
        [JsonIgnore] public Restaurant? Restaurant { get; set; } // Navigation property



        [Required]
        [Column(TypeName = "varchar(50)")]
        [ForeignKey("MenuCategory")] // Foreign Key to Restaurants table

        public string CategoryID { get; set; }
        [JsonIgnore] public MenuCategory? MenuCategory { get; set; } // Navigation property



        [Required]
        [Column(TypeName = "varchar(50)")]
        [ForeignKey("MenuSubCategory")] // Foreign Key to Restaurants table

        public string SubCategoryID { get; set; }
        [JsonIgnore] public MenuSubCategory? MenuSubCategory { get; set; } // Navigation property


        [Required]
        public int Price { get; set; }

        [StringLength(500)]
        [Column(TypeName = "varchar")]
        public string Description { get; set; }





    }
}
