﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Repositories;

namespace ZomatoApp_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderItemController : ControllerBase
    {
        private readonly IOrderItemRepository _orderItemRepository;

        public OrderItemController(IOrderItemRepository orderItemRepository)
        {
            _orderItemRepository = orderItemRepository;
        }

        [HttpGet("GetAll")]
        public async Task<ActionResult<IEnumerable<OrderItem>>> GetAllOrderItems()
        {
            var orderItems = await _orderItemRepository.GetAllOrderItems();
            return Ok(orderItems);
        }
        [HttpGet("GetByUserID/{UserId}")]
        public async Task<IActionResult> GetOrderItemByUserId(string UserId)
        {
            var orderItems = await _orderItemRepository.GetOrderItemByUserId(UserId);


            return Ok(orderItems);
        }


        [HttpPost("Add")]
        public async Task<ActionResult> AddOrderItem(OrderItem orderItem)
        {
            orderItem.OrderItemID = "OI" + new Random().Next(1000, 9999);

            await _orderItemRepository.AddOrderItem(orderItem);
            return Ok(orderItem);


          
          
        }

        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateOrderItem(int id, OrderItem orderItem)
        {
            await _orderItemRepository.UpdateOrderItem(orderItem);
            return StatusCode(200, orderItem);
        }

        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteOrderItem(int id)
        {
            await _orderItemRepository.DeleteOrderItem(id);
            return NoContent();
        }
    }
}
