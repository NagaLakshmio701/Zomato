import { Container, Row, Col, Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const HomeContent = () => {

        const foodItems = [
        { name: 'Biryani', image: 'https://assets.architecturaldigest.in/photos/600849631dd783c692024e30/master/w_1600%2Cc_limit/Mumbai-Best-Biryani-Awadhi-gosht-chap-biryani-at-Ummrao.jpg', link: '/food/1' },
        { name: 'Pizza', image: 'https://1.bp.blogspot.com/-CNzUMIzUQQM/V9p6d7-4PqI/AAAAAAABb2g/o2-Fir11lp0OBLdFd5YXMFetf9Jmc4o5QCLcB/s1600/Gluten%2BFree%2BMargherita%2BPizza%2B%25281%2529.jpg', link: '/food/2' },
        { name: 'Tiffins', image: 'https://www.lekhafoods.com/media/1051178/hurulikaalu-dosa.jpg', link: '/food/3' },
        { name: 'Milkshakes', image: 'https://th.bing.com/th/id/OIP.WgOYHxlF56xg08iv2TY1-wHaLF?w=186&h=278&c=7&r=0&o=5&dpr=1.3&pid=1.7', link: '/food/4' },
        { name: 'IceCream', image: 'https://th.bing.com/th/id/OIP.LtMMcUPnr4Y2elP74r6LtQHaHO?w=155&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7', link: '/food/5' },
        { name: 'Cake', image: 'https://th.bing.com/th/id/OIP.hWxwGuT35CNKUoNdgitZ8QHaLH?w=186&h=279&c=7&r=0&o=5&dpr=1.3&pid=1.7', link: '/food/6' },
      ];

  return (
    <Container className="my-5">
    
        {/* Second Row: Food Items */}
        <Row className="mb-4">
          {foodItems.slice(0, 3).map((foodItem, index) => (
            <Col md={4} key={index}>
              <Card className="h-100">
                <Link to={`/menu-items/${encodeURIComponent(foodItem.name)}`}>
                  <Card.Img variant="top" src={foodItem.image} alt={foodItem.name} />
                </Link>
                <Card.Body>
                  <Card.Title>{foodItem.name}</Card.Title>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row> 

        {/* Third Row: More Food Items */}
         <Row className="mb-4">
          {foodItems.slice(3, 6).map((foodItem, index) => (
            <Col md={4} key={index}>
              <Card className="h-100">
                <Link to={`/menu-items/${encodeURIComponent(foodItem.name)}`}>
                  <Card.Img variant="top" src={foodItem.image} alt={foodItem.name} style={{ height: '400px', width: '100%', objectFit: 'cover' }} />
                </Link>
                <Card.Body>
                  <Card.Title>{foodItem.name}</Card.Title>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      
    </Container>
 
  );

};

export default HomeContent;
