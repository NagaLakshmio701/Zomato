﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ZomatoApp_API.Entities;
using ZomatoApp_API.DTOS;


namespace ZomatoApp_API.Repositories
{
    public interface IMenuItemRepository
    {
        Task<IEnumerable<MenuItem>> GetAll();
        Task<IEnumerable<MenuItemDTO>> GetByUId(string   Uid);
        Task<IEnumerable<MenuItemDTO>> GetMenuByCategoryName(string categoryName);
        Task<IEnumerable<MenuItem>> GetMenuBySubCategoryName(string subCategoryName);
        Task<List<MenuItemDTO>> GetMenuByRestaurantName(string restaurantName);
        Task<IEnumerable<MenuItemDTO>> GetItemsByFilterAsync(decimal? minPrice, decimal? maxPrice, string? Type,decimal? Rating,string?CategoryName,string? restaurantname);
        Task Add(MenuItem menuItem);
        Task Update(MenuItem menuItem);
        Task Delete(string id);
    }
}
