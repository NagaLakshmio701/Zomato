import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const ManageRestaurants = () => {
  const [restaurants, setRestaurants] = useState([]);
  const navigate = useNavigate();

  // Fetch restaurants
  useEffect(() => {
    axios
      .get("http://localhost:5141/api/Restaurant/GetAllRestaurants", {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        setRestaurants(response.data); // Update state with the fetched data
      })
      .catch((error) => console.log(error));
  }, []);

  // Remove restaurant
  const removeRestaurant = (restaurantId) => {
    axios
      .delete(`http://localhost:5141/api/Restaurant/DeleteRestaurant/${restaurantId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        setRestaurants((prevRestaurants) =>
          prevRestaurants.filter((r) => r.restaurantID !== restaurantId)
        );
      })
      .catch((error) => console.log(error));
  };

  // Update restaurant
  const updateRestaurant = (restaurantId) => {
    sessionStorage.setItem("RestID", restaurantId);
    navigate("/update-restaurant");
  };

  return (
    <div className="container my-4">
      <h1 className="mb-4">Manage Restaurants</h1>
      <div className="table-responsive">
        <table className="table table-striped table-bordered table-hover">
          <thead className="table-dark">
            <tr>
              <th>Id</th>
              <th>Owner ID</th>
              <th>Name</th>
              <th>Location</th>
              <th>Phone Number</th>
              <th>Rating</th>
              <th>Opening Time</th>
              <th>Closing Time</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {restaurants.map((r) => (
              <tr key={r.restaurantID}>
                <td>{r.restaurantID}</td>
                <td>{r.ownerID}</td>
                <td>{r.restaurantName}</td>
                <td>{r.location}</td>
                <td>{r.phoneNumber}</td>
                <td>{r.rating}</td>
                <td>{r.openingTime}</td>
                <td>{r.closingTime}</td>
                <td>
                  <button
                    type="button"
                    className="btn btn-danger btn-sm me-2"
                    onClick={() => removeRestaurant(r.restaurantID)}
                  >
                    Delete
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={() => updateRestaurant(r.restaurantID)}
                  >
                    Update
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ManageRestaurants;
