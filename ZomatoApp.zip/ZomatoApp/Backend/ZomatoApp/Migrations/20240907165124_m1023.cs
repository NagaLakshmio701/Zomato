﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ZomatoApp_API.Migrations
{
    /// <inheritdoc />
    public partial class m1023 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "UserID",
                table: "OrderItems",
                type: "varchar(50)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_OrderItems_UserID",
                table: "OrderItems",
                column: "UserID");

            migrationBuilder.AddForeignKey(
                name: "FK_OrderItems_Users_UserID",
                table: "OrderItems",
                column: "UserID",
                principalTable: "Users",
                principalColumn: "UserID",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_OrderItems_Users_UserID",
                table: "OrderItems");

            migrationBuilder.DropIndex(
                name: "IX_OrderItems_UserID",
                table: "OrderItems");

            migrationBuilder.DropColumn(
                name: "UserID",
                table: "OrderItems");
        }
    }
}
