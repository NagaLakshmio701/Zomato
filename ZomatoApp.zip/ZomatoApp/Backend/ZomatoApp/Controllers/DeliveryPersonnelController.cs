﻿

using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Repositories;

namespace ZomatoAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
/*    [Authorize]
*/    public class DeliveryPersonnelController : ControllerBase
    {
        private readonly IDeliveryPersonnelRepository _deliveryPersonnelRepository;

        public DeliveryPersonnelController(IDeliveryPersonnelRepository deliveryPersonnelRepository)
        {
            _deliveryPersonnelRepository = deliveryPersonnelRepository;
        }

        [HttpGet, Route("GetAll")]

        public async Task<IActionResult> GetAll()
        {
            try
            {
                return Ok(await _deliveryPersonnelRepository.GetAll());
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpGet, Route("GetById/{id}")]

        public async Task<IActionResult> GetById([FromRoute] string id)
        {
            try
            {
                var deliveryPersonnel = await _deliveryPersonnelRepository.GetById(id);
                if (deliveryPersonnel == null)
                {
                    return NotFound();
                }
                return Ok(deliveryPersonnel);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpPost, Route("AddDeliveryPersonnel")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Add([FromBody] DeliveryPersonnel deliveryPersonnel)
        {
            try
            {
                deliveryPersonnel.DeliveryPersonnelID = "D" + new Random().Next(1000, 9999);

                await _deliveryPersonnelRepository.Add(deliveryPersonnel);
                return Ok(deliveryPersonnel);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpPut, Route("EditDeliveryPersonnel")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit([FromBody] DeliveryPersonnel deliveryPersonnel)
        {
            try
            {
                await _deliveryPersonnelRepository.Update(deliveryPersonnel);
                return Ok(deliveryPersonnel);
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }

        [HttpDelete, Route("DeleteDeliveryPersonnel/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete([FromRoute] string id)
        {
            try
            {
                await _deliveryPersonnelRepository.DeleteById(id);
                return Ok();
            }
            catch (Exception ex)
            {

                return BadRequest(new { message = "An error occurred while validating the user.", error = ex.Message });
            }
        }
    }

}