﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public interface IMenuSubCategoryRepository
    {
        Task<IEnumerable<MenuSubCategory>> GetAll();
        Task<MenuSubCategory> GetBySubCategoryName(string subCategoryName);
        Task<IEnumerable<MenuSubCategory>>GetByCategoryName(string CategoryName);

        Task Add(MenuSubCategory menuSubCategory);
        Task Update(MenuSubCategory menuSubCategory);
        Task Delete(string subCategoryID);
    }
}
