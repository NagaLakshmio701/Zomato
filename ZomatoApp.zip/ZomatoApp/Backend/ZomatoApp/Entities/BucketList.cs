﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ZomatoApp_API.Entities
{
    public class BucketList
    {
        [Key]
        [Required]
        [Column(TypeName = "varchar(50)")]
        public string BucketListID { get; set; } // Primary Key as String


        [ForeignKey("User")]
        [Required]
        [Column(TypeName = "varchar(50)")]

        public String UserID { get; set; } // Foreign Key to Users table
        [JsonIgnore] public User? User { get; set; }


        [Required]
        [ForeignKey("MenuItem")]
        [Column(TypeName = "varchar(50)")]

        public String MenuItemID { get; set; } // Foreign Key to MenuItems table
        [JsonIgnore] public MenuItem? MenuItem { get; set; }

        

        [Required(ErrorMessage = "Price is Required")]

        public double Price { get; set; }


        [Required(ErrorMessage = "Quantity is Required")]
        public int Quantity { get; set; }

        public double TotalPrice { get; set; }


    



    }

}
