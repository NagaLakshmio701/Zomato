﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public class DeliveryPersonnelRepository : IDeliveryPersonnelRepository
    {
        private readonly ZomatoAppDBContext _context;

        public DeliveryPersonnelRepository(ZomatoAppDBContext context)
        {
            _context = context;
        }

        public async Task Add(DeliveryPersonnel deliveryPersonnel)
        {
            await _context.DeliveryPersonnels.AddAsync(deliveryPersonnel);
            await _context.SaveChangesAsync();
        }

        public async Task<DeliveryPersonnel> GetById(string id)
        {
            return await _context.DeliveryPersonnels.SingleOrDefaultAsync(dp => dp.DeliveryPersonnelID == id);
        }

        public async Task<List<DeliveryPersonnel>> GetAll()
        {
            return await _context.DeliveryPersonnels.ToListAsync();
        }

        public async Task Update(DeliveryPersonnel deliveryPersonnel)
        {
            _context.DeliveryPersonnels.Update(deliveryPersonnel);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteById(string id)
        {
            var deliveryPersonnel = await _context.DeliveryPersonnels.FindAsync(id);
            _context.DeliveryPersonnels.Remove(deliveryPersonnel);
            await _context.SaveChangesAsync();
        }
    }
}
