﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public interface IRestaurantRepository
    {
        // Asynchronously retrieves a restaurant by its ID.
        Task<IEnumerable<Restaurant>> GetByOwnerId(string Ownerid);

        Task<Restaurant> GetById(string id);


        // Asynchronously retrieves all restaurants.
        Task<IEnumerable<Restaurant>> GetAll();



        // Asynchronously retrieves menu items by a specific restaurant ID.
        Task<IEnumerable<Restaurant>> GetMenuByRestaurantName(string restaurantname);


        // Asynchronously adds a new restaurant.
        Task Add(Restaurant restaurant);

        // Asynchronously updates an existing restaurant.
        Task Update(Restaurant restaurant);

        // Asynchronously deletes a restaurant by its ID.
        Task Delete(string id);
    }
}
