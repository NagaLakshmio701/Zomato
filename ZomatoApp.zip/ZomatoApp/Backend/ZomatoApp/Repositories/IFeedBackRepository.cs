﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public interface IFeedbackRepository
    {
        Task Add(FeedBack feedback);
        Task<FeedBack> GetById(string id);

        // Feedback Repository
        Task<IEnumerable<FeedBack>> GetFeedbacksByRating(decimal? minRating, decimal? maxRating);
        Task<IEnumerable<FeedBack>> GetFeedbacksByRestaurantAsync(string restaurantname);
        Task<List<FeedBack>> GetAll();
        Task Update(FeedBack feedback);
        Task DeleteById(string id);
    }
}
