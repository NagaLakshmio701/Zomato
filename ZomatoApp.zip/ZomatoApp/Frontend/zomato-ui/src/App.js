import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
// import HomePage from './Layout/HomePage';
import Login from './Authentication/Login';
import Register from './Authentication/Register';
import SearchBar from './Layout/SearchBar';
import Footer from './Layout/Footer';
import Logout from './Authentication/Logout';
import ViewCart from './ViewCart';
import UserDashboard from './Dashboards/user-dashboard';
import Payment from './Payments/payment';
import Profile from './Authentication/Profile';
import AdminDashboard from './Dashboards/admin-dashboard';
import ManageRestaurants from './ManageRestaurants';
import ManageUsers  from './ManageUsers';
import ManageOrders  from './ManageOrders';
import Layout  from './Layout';
import UpdateRestaurant from './UpdateRestaurant';
import FeedbackManagement from './ManageFeedbacks';
import ManageAndUpdateDeliveryPersonnel from './ManageDeliveryPersonnel';
import ManageTransactions from './ManageTransactions';
import RestaurantOwnerDashboard from './Dashboards/owner-dashboard';
import ManageRestaurantProfile from './ManageRestaurantProfile';
import ManageMenu from './ManageMenu';
import MenuItems  from './Layout/MenuItems';
// import AdminHomePage from './Layout/AdminHomePage'
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<UserDashboard />} />
          <Route path="/login" element={<Login />} />
          <Route path="/menu-items/:foodName" element={<MenuItems />} />


          <Route path="/register" element={<Register />} />
          <Route path="/logout" element={<Logout />} />
          <Route path="/search-bar" element={<SearchBar />} />
          <Route path="/footer" element={<Footer />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/viewcart" element={<ViewCart />} />
          <Route path="/tran" element={<Payment />} />

        


          {/* Admin Dashboard with nested routes */}
          {/* <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/manage-restaurants" element={<ManageRestaurants />} />
        <Route path="/manage-users" element={<ManageUsers />} />
        <Route path="/view-orders" element={<ManageOrders />} /> */}


        <Route path="/" element={<Layout />}>
          {/* Child routes rendered in Outlet */}
          <Route  path="/admin-dashboard"  element={<AdminDashboard />} />
          <Route path="/manage-restaurants" element={<ManageRestaurants />} />
          <Route path="/manage-users" element={<ManageUsers />} />
          <Route path="/view-orders" element={<ManageOrders />} />
          <Route path="/view-feedback" element={<FeedbackManagement/>} />
          <Route path="/view-deliverypersonnel"  element={<ManageAndUpdateDeliveryPersonnel/>}/>
          <Route path="/view-transactions"element={<ManageTransactions/>}/>
          <Route path="/update-restaurant" element={<UpdateRestaurant />} />

          {/* Add more routes as needed */}
        </Route>

        <Route path="/" element ={<Layout/>}>
        <Route  path="/owner-dashboard"  element={<RestaurantOwnerDashboard />} />
        <Route path="/view-restaurant-profile" element={<ManageRestaurantProfile />} />
        <Route path="/manage-menu" element={<ManageMenu />} />



        </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
