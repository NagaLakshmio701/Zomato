﻿using Microsoft.EntityFrameworkCore;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public class FeedBackRepository:IFeedbackRepository
    {

            private readonly ZomatoAppDBContext _context;

        public FeedBackRepository(ZomatoAppDBContext context)
        {
                _context = context;
            }

            public async Task Add(FeedBack feedback)
        {
                await _context.FeedBacks.AddAsync(feedback);
            await _context.SaveChangesAsync();
            }

            public async Task<FeedBack> GetById(string id)
        {
                return await _context.FeedBacks.SingleOrDefaultAsync(f => f.FeedbackID == id);
        }


        public async Task<IEnumerable<FeedBack>> GetFeedbacksByRating(decimal? minRating, decimal? maxRating)
        {
            var query = _context.FeedBacks.AsQueryable();

            if (minRating.HasValue)
            {
                query = query.Where(fb => fb.Rating >= minRating.Value);
            }

            if (maxRating.HasValue)
            {
                query = query.Where(fb => fb.Rating <= maxRating.Value);
            }

            return await query.ToListAsync();
        }

        public async Task<IEnumerable<FeedBack>> GetFeedbacksByRestaurantAsync(string restaurantname)
        {
            return await _context.FeedBacks
                .Where(f => f.Restaurant.RestaurantName==restaurantname)
                .OrderByDescending(f => f.FeedbackDate) // Optional: Sort by feedback date
                .ToListAsync();
        }

        public async Task<List<FeedBack>> GetAll()
        {
                return await _context.FeedBacks.ToListAsync();
        }

            public async Task Update(FeedBack feedback)
        {
                _context.FeedBacks.Update(feedback);
            await _context.SaveChangesAsync();
            }

            public async Task DeleteById(string id)
            {
                var feedback = await _context.FeedBacks.FindAsync(id);
            _context.FeedBacks.Remove(feedback);
            await _context.SaveChangesAsync();
            }
        }
    }


