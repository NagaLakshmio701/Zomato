import React from "react";
import { Link, Outlet } from "react-router-dom";
import { Navbar, Nav, Container, Row, Col, Button, Card } from 'react-bootstrap';
import Header  from "../Layout/Header";

import Footer  from "../Layout/Footer";
import SearchBar  from "../Layout/SearchBar";
export default function UserDashboard() {
    
return (

    <div>

        <div>  <Header/></div>


      <div> <SearchBar/></div>

     

        <main>

        <Outlet /> 
        
      </main>


      <div>     <Footer/>    </div>



</div>
)
}

      


     
      

      
      

     