﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ZomatoApp_API.Entities;
using ZomatoApp_API.Repositories;

namespace ZomatoApp_API.Controllers
{
    // Defines the route for the controller and marks it as an API controller.
    [Route("api/[controller]")]
    [ApiController]
    public class BucketListController : ControllerBase
    {
        private readonly IBucketListRepository _bucketListRepository;

        // Constructor to initialize the bucket list repository dependency.
        public BucketListController(IBucketListRepository bucketListRepository)
        {
            _bucketListRepository = bucketListRepository;
        }

        // Endpoint to retrieve all bucket lists.
        [HttpGet, Route("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                // Retrieve all bucket lists asynchronously.
                var bucketLists = await _bucketListRepository.GetAll();

                // Return the list of bucket lists.
                return Ok(bucketLists);
            }
            catch (Exception ex)
            {
                // Handle any exceptions and return a 500 status code with the error message.
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Endpoint to retrieve a specific bucket list by its ID.
        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> GetById([FromRoute] string id)
        {
            try
            {
                // Retrieve the bucket list by ID asynchronously.
                var bucketList = await _bucketListRepository.GetById(id);

                // If the bucket list is not found, return a 404 status code.
                if (bucketList == null)
                {
                    return NotFound();
                }

                // Return the found bucket list.
                return Ok(bucketList);
            }
            catch (Exception ex)
            {
                // Handle any exceptions and return a 500 status code with the error message.
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpGet("GetBucketListByUserID/{userId}")]
        public async Task<IActionResult> GetBucketListByUserID(string userId)
        {
            var bucketlist = await _bucketListRepository.GetBucketListByUserID(userId);

            return Ok(bucketlist);
        }

        // Endpoint to add a new bucket list. Restricted to users with the "User" role.
        [HttpPost, Route("AddBucketList")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Add([FromBody] BucketList bucketList)
        {
            try
            {
                // Generate a random BucketListID.
                bucketList.BucketListID = "B" + new Random().Next(1000, 9999);

                // Add the bucket list asynchronously.
                await _bucketListRepository.Add(bucketList);

                // Return the newly added bucket list.
                return Ok(bucketList);
            }
            catch (Exception ex)
            {
                // Handle any exceptions and return a 500 status code with the error message.
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Endpoint to edit an existing bucket list. Restricted to users with the "User" role.
        [HttpPut, Route("EditBucketList")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Edit([FromBody] BucketList bucketList)
        {
            try
            {
                // Update the bucket list asynchronously.
                await _bucketListRepository.Update(bucketList);

                // Return the updated bucket list.
                return Ok(bucketList);
            }
            catch (Exception ex)
            {
                // Handle any exceptions and return a 500 status code with the error message.
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Endpoint to delete a bucket list by its ID. Restricted to users with the "User" role.
        [HttpDelete, Route("DeleteBucketList/{id}")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Delete([FromRoute] string id)
        {
            try
            {
                // Delete the bucket list by ID asynchronously.
                await _bucketListRepository.DeleteById(id);

                // Return a success response.
                return Ok();
            }
            catch (Exception ex)
            {
                // Handle any exceptions and return a 500 status code with the error message.
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("DeleteBucketListByUserId/{userId}")]
        public async Task<IActionResult> DeleteBucketListByUserId(string userId)
        {
            await _bucketListRepository.DeleteBucketListByUserId(userId);
            return NoContent();
        }
    }
}


