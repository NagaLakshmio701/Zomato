import { useState, useEffect } from "react";
import axios from "axios";

const ManageMenu = () => {
  const [menuItems, setMenuItems] = useState([]);
  const [menuItem, setMenuItem] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const userId = sessionStorage.getItem("userid"); // Adjust as needed
    axios
      .get(`http://localhost:5141/api/MenuItems/GetById/${userId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        setMenuItems(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setLoading(false);
        setError("Failed to load menu items.");
        console.error(error);
      });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setMenuItem((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleAdd = () => {
    axios
      .post("http://localhost:5141/api/MenuItems/add", menuItem, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        alert("Menu item added successfully!");
        setMenuItem({});
        fetchMenuItems(); // Refresh the menu items list
      })
      .catch((error) => {
        setError("Failed to add menu item.");
        console.error(error);
      });
  };

  const handleUpdate = (menuItemId) => {
    axios
      .put("http://localhost:5141/api/MenuItems/update", { ...menuItem, menuItemID: menuItemId }, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        alert("Menu item updated successfully!");
        setMenuItem({});
        fetchMenuItems(); // Refresh the menu items list
      })
      .catch((error) => {
        setError("Failed to update menu item.");
        console.error(error);
      });
  };

  const handleDelete = (menuItemId) => {
    axios
      .delete(`http://localhost:5141/api/MenuItems/delete/${menuItemId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then(() => {
        alert("Menu item deleted successfully!");
        fetchMenuItems(); // Refresh the menu items list
      })
      .catch((error) => {
        setError("Failed to delete menu item.");
        console.error(error);
      });
  };

  const fetchMenuItems = () => {
    const userId = sessionStorage.getItem("userid"); // Adjust as needed
    axios
      .get(`http://localhost:5141/api/MenuItems/GetById/${userId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => setMenuItems(response.data))
      .catch((error) => {
        setError("Failed to load menu items.");
        console.error(error);
      });
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div className="container">
      <h2>Manage Menu</h2>

      {error && <div className="alert alert-danger">{error}</div>}

      {/* Add Menu Item Form */}
      <h3>Add Menu Item</h3>
      <form>
        <div className="mb-3">
          <label>Menu Item ID</label>
          <input
            type="text"
            name="menuItemID"
            value={menuItem.menuItemID || ''}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label>Restaurant ID</label>
          <input
            type="text"
            name="restaurantID"
            value={menuItem.restaurantID || ''}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label>Category ID</label>
          <input
            type="text"
            name="categoryID"
            value={menuItem.categoryID || ''}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label>Sub Category ID</label>
          <input
            type="text"
            name="subCategoryID"
            value={menuItem.subCategoryID || ''}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label>Price</label>
          <input
            type="number"
            step="0.01"
            name="price"
            value={menuItem.price || ''}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label>Description</label>
          <input
            type="text"
            name="description"
            value={menuItem.description || ''}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <button type="button" onClick={handleAdd} className="btn btn-primary">
          Add Menu Item
        </button>
      </form>

      {/* Display Menu Items */}
      <h3>Menu Items List</h3>
      <table className="table table-bordered table-hover">
        <thead className="thead-dark">
          <tr>
            <th>Menu Item ID</th>
            <th>Restaurant ID</th>
            <th>Restaurant Name</th>
            <th>Category Name</th>
            <th>Price</th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {menuItems.length > 0 ? (
            menuItems.map((item) => (
              <tr key={item.menuItemID}>
                <td>{item.menuItemID}</td>
                <td>{item.restaurantID}</td>
                <td>{item.restaurantName}</td>
                <td>{item.categoryName}</td>
                <td>{item.price}</td>
                <td>{item.description}</td>
                <td>
                  <button onClick={() => handleUpdate(item.menuItemID)} className="btn btn-warning btn-sm me-2">
                    Update
                  </button>
                  <button onClick={() => handleDelete(item.menuItemID)} className="btn btn-danger btn-sm">
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7" className="text-center">No menu items found</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ManageMenu;
