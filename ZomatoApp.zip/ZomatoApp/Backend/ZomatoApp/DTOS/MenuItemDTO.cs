﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.DTOS
{
    public class MenuItemDTO
    {

            
            public string MenuItemID { get; set; }

        public string UserID {  get; set; }

            public string RestaurantID { get; set; }


           public string RestaurantName { get; set; }

         public string CategoryName {  get; set; }


            public string SubCategoryName { get; set; }


            public int Price { get; set; }

   
            public string Description { get; set; }





        }
    }


