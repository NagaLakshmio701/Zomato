﻿using Microsoft.EntityFrameworkCore;
using ZomatoApp_API.Entities;

namespace ZomatoApp_API.Repositories
{
    public class BucketListRepository : IBucketListRepository
    {
            private readonly ZomatoAppDBContext _context;

        public BucketListRepository(ZomatoAppDBContext context)
        {
                _context = context;
            }

            public async Task Add(BucketList bucketList)
            {
                await _context.BucketLists.AddAsync(bucketList);
                await _context.SaveChangesAsync();
            }

            public async Task<BucketList> GetById(string id)
            {
                return await _context.BucketLists.SingleOrDefaultAsync(bl => bl.BucketListID == id);
        }

        public async Task<IEnumerable<BucketList>> GetBucketListByUserID(string userId)
        {
            return await _context.BucketLists
                .Where(f => f.UserID == userId)
                .ToListAsync();
        }


        public async Task<List<BucketList>> GetAll()
            {
                return await _context.BucketLists.ToListAsync();
            }

            public async Task Update(BucketList bucketList)
            {
                _context.BucketLists.Update(bucketList);
                await _context.SaveChangesAsync();
            }

            public async Task DeleteById(string id)
            {
                var bucketList = await _context.BucketLists.FindAsync(id);
                _context.BucketLists.Remove(bucketList);
                await _context.SaveChangesAsync();
            }


        public async Task DeleteBucketListByUserId(string userId)
        {
            var bucketLists = await _context.BucketLists
                .Where(bl => bl.UserID == userId)
                .ToListAsync();

            if (bucketLists.Any())
            {
                _context.BucketLists.RemoveRange(bucketLists);
                await _context.SaveChangesAsync();
            }
        }
    }
    }

